import 'dotenv/config';
import { join } from 'node:path';
import qrcode from 'qrcode-terminal';
import { useMultiFileAuthState } from 'baileys';
import {
  createHardenedBaileysAdapter,
  installShutdownHandlers,
} from './whatsapp_baileys.mjs';
import { createCervellHandler } from './cervell_bridge.mjs';
import { iniciaCervell, pensa, transcriuAudio, generaImatge } from './cervell.mjs';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const DATA_ROOT = process.env.IAIA_STATE_ROOT || __dirname;
const AUTH_DIR = join(DATA_ROOT, '.iaia_auth');
const RUNTIME_DIR = join(DATA_ROOT, 'var', 'baileys-runtime');

process.on('unhandledRejection', (reason, promise) => {
  console.error('[FATAL] Promesa no gestionada:', reason);
  process.exit(1);
});

process.on('uncaughtException', (error) => {
  console.error('[FATAL] Excepció no capturada:', error);
  process.exit(1);
});
async function main() {
  console.log('[BOT] Iniciant el cervell...');
  await iniciaCervell();

  const cervell = {
    pensa,
    transcriuAudio,
    generaImatge
  };

  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

  const soroll = (lvl) => (obj, msg) => console.error(`[WA:${lvl}]`, msg ?? '', obj ?? '');
  const consoleLogger = {
    level: 'info',
    child: () => consoleLogger,
    trace: () => {}, debug: () => {}, info: soroll('info'),
    warn: soroll('warn'), error: soroll('error'), fatal: soroll('fatal'),
  };

  const whatsapp = await createHardenedBaileysAdapter({
    logger: consoleLogger,
    authState: state,
    saveCreds,
    handleInbound: createCervellHandler(cervell),
    dataDir: RUNTIME_DIR,
    onQr: (qr) => qrcode.generate(qr, { small: true }),
    onReady: () => console.info('[WHATSAPP] IAIA MarIA connectada'),
    onFatal: (error) => {
      console.error('[WHATSAPP] Intervenció manual:', error.message);
      process.exit(1);
    },
    onLimitState: (limitState) => console.warn('[WHATSAPP] Restricció/circuit:', limitState.type),
    config: {
      // Fail-closed: sense esta llista, no contesta en cap grup.
      allowedGroupJids: [],
      allowAllGroups: true,
    },
  });

  installShutdownHandlers(whatsapp);
}

main().catch(err => {
  console.error("[BOT] Error fatal a l'arrancada:", err);
  process.exit(1);
});
