---
estat: canonic
tipus: document
description: 'Defineix el Trellat com a prudència verificable: simplicitat, accessibilitat,
  reversibilitat i evidència abans d''afirmar.'
temes:
- sistema
tags:
- coneixement
- cultura
- saber
- socdepoble
---
# El Trellat — patró de disseny rústic

Trellat és saviesa pràctica: buscar la solució útil sense complicar la vida de
les persones ni inventar garanties que el sistema encara no pot provar.

## Regles de ferro

1. **Complexitat justificada:** dins de la carcassa React/Vite actual, preferix
   la peça més simple que resolga el cas i evita capes o dependències gratuïtes.
2. **Accessibilitat de Pedra Seca:** text llegible, focus visible, semàntica i
   objectius tàctils adequats; els 48 px i 16 px són mínims de disseny que cal
   comprovar en la interfície real.
3. **Resiliència demostrada:** els fallbacks locals actuals es proven en
   desconnexió i recuperació. CRDT/Y.js/WebRTC és una línia futura, no un fet.
4. **Esporgar amb reversibilitat:** cap neteja massiva sense pla, Reflex, backup,
   CAS, verificació i restauració.
5. **Evidència abans d'adjectius:** “perfecte”, “blindat”, “autònom” o “100%”
   exigixen scope, denominador, prova i data.

## Test abans de proposar

1. Quin problema humà resol i quina és la peça mínima?
2. Què passa en iPad A10/Safari, poca memòria i pèrdua de xarxa?
3. Quina evidència existix i què continua sent una hipòtesi?
4. Com es detecta una fallada i com es torna arrere?
5. Una altra persona o agent podrà localitzar l'autoritat sense carregar tota
   la Wiki?

Trellat no obliga a reescriure React en Vanilla per principi. Obliga a mesurar
el cost, conservar la frontera del projecte i evitar que la ferramenta es
convertisca en dogma.


## Taxonomia
- **Categoria:** [[Coneixement]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---

**Ancoratge de Seguretat:** [[00_INDEX]]