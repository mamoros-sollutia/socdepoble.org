---
estat: canonic
tipus: document
description: Defineix una interacció centrada en connectar recursos, sense mètriques
  socials d'aprovació.
temes:
- sistema
tags:
- coneixement
- cultura
- saber
- socdepoble
---
# Connexió Radical (Anti-Me-Gusta)

Aquest document defineix la filosofia de disseny i interacció de [[el_projecte|Sóc de Poble]]. Orienta una xarxa social local pensada per guardar i connectar continguts, no per premiar l'aprovació superficial.

## 1. El Botó "Connectar" és la Interacció Cúspide
Hi ha un concepte horitzontal que travessa tot el projecte i totes les "cards": **El Botó Connectar**.
- **La Card ho connecta tot:** Qualsevol element en forma de targeta (card) ha de tindre sempre com a botó principal i exclusiu "Connectar".
- **Única excepció (Salir):** L'única excepció per no posar "Connectar" a un botó d'una card és quan es tracta de l'acció de "Eixir" o "Salir" del sistema (ja que connectar per sortir seria un contrasentit). 
- **Funció:** Fer clic en "Connectar" porta a l'usuari a una pàgina específica on decideix què fer exactament amb eixa targeta i com enllaçar-la a la seua xarxa de coneixement personal.
- **Prohibició de distraccions:** MAI poseu a la targeta altres botons d'acció primària o accessos directes que diluïsquen aquesta via única.

## 2. Filosofia Anti-Likes
- **Som "anti-me-gusta" i "anti-corazoncitos".** 
- La plataforma no fomenta la validació superficial. Elimina del teu cap l'arquitectura clàssica de les xarxes socials corporatives (Cors, Estrelles, Polzes amunt).
- L'única acció vàlida davant del contingut és "Connectar-lo" a un altre contingut o a un mateix (apropiació de coneixement).

## 3. Privacitat Absoluta per Defecte
- Qualsevol connexió, nota, o contingut guardat és **SEMPRE PRIVAT** per defecte.
- El sistema permet compartir contingut en públic si l'usuari ho decideix explícitament a posteriori.
- L'arquitectura s'ha de pensar primer com a un arxiu privat i, en segon terme, com a una àgora pública d'exportació de nodes de coneixement.


## Taxonomia
- **Categoria:** [[Coneixement]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---

**Ancoratge de Seguretat:** [[00_INDEX]]