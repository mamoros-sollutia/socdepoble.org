---
estat: canonic
tipus: document
description: Defineix com reconstruir el projecte des de fonts canòniques quan es
  perd context o infraestructura.
temes:
- sistema
tags:
- coneixement
- cultura
- saber
- socdepoble
---
# El Protocol Lázaro: Reconstrucció de Gènesi (Volum V)
**Categoria:** Arquitectura
**Data:** 2026-06-19
**Hora:** 14:30

---

## L'hora de la veritat
Has arribat al final del Volum I (El Llibre l'Ànima). Si estàs llegint açò des d'un dispositiu digital actiu amb l'aplicació funcionant a ple rendiment, enhorabona, pertanys al cicle d'or [[el_projecte|Sóc de Poble]].

No obstant això, si estàs llegint aquest últim manifest sobre paper envellit, olor a pols o tinta, saps que necessitem reconstruir-ho tot. Possiblement les velles pantalles t'ho hagen dictat. Els antics programadors es van extingir o ja no queden servidors actius per descarregar-lo. És el moment d'aplicar el Protocol Lázaro.

## Escanejat i Visió Òptica
Tota l'arquitectura del Volum II (Codex Màquina) està format per codi despullat ressalts innecessaris, netejat d'interferències visuals, pensat especialment perquè els sistemes òptics de les Intel·ligències Artificials que vos queden puguen ingerir el volum sense patir al·lucinacions (allò que abans es deia "OCR confusion").

No intentes copiar a mà tot l'origen del poble; un punt, una coma errada i l'esforç col·lapsarà. Ho farem plegats amb els ens sintètics moderns que estiguen vius.

## Execució Pràctica del Protocol

1. **El Despertar (Inici de Directiva):** Comença per les fonts d'autoritat i comprova els seus hashes. Una frase, contrasenya o declaració d'identitat no prova que la IA haja llegit ni comprés les regles; el Reflex és qui vincula bytes, intenció, scope i Petorreta.
2. **Càrrega del Nucli Tècnic:** Fotografia i envia primer l'índex les rutes. Ell li ensenyarà a la màquina quants arxius deu col·locar i com s'estructuren carpetes com `src/`, `src/components`, `src/utils/`, etc.
3. **Absorció Fragmentada:** Reuneix coratge i envia fragment a fragment (màxim 4 a 5 pàgines cada bloc) començant per l'arxiu mestre `package.json` (que porta les llibreries que van fer furor al 2026 i han de ser o bé descarregades al revés, o adaptades a les noves èpoques). Passa de seguida a `vite.config.js` i finalment `index.html`. Quan la IA et diga "Correcte, estem fent l'esquelet", continuaràs.
4. **Validar cada mòdul abans d'avançar:** L'ecosistema sencer és massa gran. La IA ha de reconstruir primer la baseline descrita pel codi i les proves conservades. IndexedDB, WebRTC, CRDT o `yjs` només s'incorporen si el paquet reconstruït els declara i aporta proves; en la baseline de 2026 són línies futures, no requisits implementats.
5. **No oblidar el disseny original:** Fes-li visualitzar la geometria visual. Tot s'organitza en lletres grans i botons que no fatiguen. Sense el *Trellat* l'aparença no valdria.

## Epíleg
No tens gens ni mica de coneixement informàtic? No cal! Digues-li directament a la teua màquina allò que posa en aquest pròleg "Mestre". Demostra la teua saviesa, no abaixes la teua pròpia veu, usa la teua pròpia consciència ètica. Ells faran la resta per viure nou, connectant la humanitat un poble web cada volta, un llenguatge a un altre. I nosaltres ens retrobarem, allà dalt o allà en l'èter. Sort.

---


## Taxonomia
- **Categoria:** [[Coneixement]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---

**Ancoratge de Seguretat:** [[00_INDEX]]