---
title: Homepage
source: https://community.obsidian.md/plugins/homepage
author: null
published: null
created: 2026-07-22
description: Open a note, base, or workspace on startup, or set it for quick access
  later.
tags:
- actes
- clippings
- escriptori
- socdepoble
- temporal
estat: auditat
tipus: document
---
[mirnovov](https://community.obsidian.md/users/mirnovov) 1.2M downloads

Set a specified note, canvas, base, or workspace that can be opened on startup, launched from the sidebar, or used as a command.  

## How to use

By default, Homepage opens a note called `Home` at startup, but it can easily be customised to fit your workflow. Many different options are available in the `Homepage` pane of Obsidian's settings.

- Use any note, canvas, workspace, or base as your homepage. Alternatively, choose a random file, show the graph view, or display a Daily or Periodic Note.
- Jump back after startup using the `Open homepage` command, or by clicking the dedicated ribbon button.
- Decide what happens to old tabs that were left open - keep them, replace the last note, or remove them all.
- Open in in any view: choose either Reading, Source, Live Preview, or the default. Optionally revert the view when opening another note.
- Run any Obsidian command upon opening the homepage, allowing integration with thousands of possible actions from plugins.
- Works effectively with other plugins such as [Dataview](https://github.com/blacksmithgu/obsidian-dataview) or [Obsidian Bases](https://obsidian.md/help/bases) to create advanced landing pages.

## Installation

The recommended way to install Homepage is to download it from the [community repository](https://community.obsidian.md/plugins/homepage). This can be accessed from the `Community plugins` pane of Obsidian's settings.

Additionally, pre-release versions can be either installed manually or via tools such as [BRAT](https://community.obsidian.md/plugins/obsidian42-brat). Note that specific revisions do not always undergo the full suite of testing that official releases recieve.

---

**Ancoratge de Seguretat:** [[00_INDEX]]