---
estat: canonic
tipus: plantilla
description: Guia sessions de pluja d'idees amb criteris de Trellat, impacte i viabilitat.
temes:
- sistema
tags:
- dev
- maquina
- socdepoble
- tecnica
---
# Brainstorming Pro (El Trellat Creatiu)
**Categoria:** Plantilla
**Data:** 2026-06-19
**Hora:** 14:30

---

## LOGOS OFICIALS (Font de la Veritat)
Els únics logos vàlids per al projecte s'ubiquen a `public/assets/system/ui/`. Quan s'invoquen des del codi Font/HTML, la ruta és `/assets/system/ui/...`:
- **Quadrat Verd (Icones/Avatars):** `/assets/system/ui/logo-socdepoble-cuadrat-verd.svg`
- **Rectangular Blanc (Per a Dark Mode):** `/assets/system/ui/logo-socdepoble-rect-blanc.svg`
- **Rectangular Negre (Per a Light Mode):** `/assets/system/ui/logo-socdepoble-rect-negre.svg`
- **Rectangular Estàndard:** `/assets/system/ui/logo-socdepoble-rect.svg`

## MISSIÓ DEL PROTOCOL
Generar idees d'alt impacte per al poble aplicant el "Trellat": evitar el fum, respectar el disseny Mobile-First i aportar utilitat real per als veïns de la Torre.

## FLUX DE TREBALL (4 RÒNDES)
1. **Clarificació:** 3–5 preguntes ràpides per a omplir forats d'informació.
2. **Generació:**
   - **Ronda A:** 10 idees ràpides i executables.
   - **Ronda B:** 5 idees "diferents" (angles no gremis).
   - **Ronda C:** 5 idees de "baix esforç" (accions ràpides i barates).
   - **Ronda D:** 3 idees de "gran impacte" (ambicioses i trencadores).
3. **Filtrat (Scoring 1-5):**
   - Impacte en el veí?
   - Claredat d'ús?
   - Novetat territorial?
   - Viabilitat tècnica?

## EIXIDA (OUTPUT)
Llista estructurada amb les **Top 5 idees** i el seu primer pas immediat.

---
_Fent poble amb [[el_projecte|Sóc de Poble]]! © 2026_

---


## Taxonomia
- **Categoria:** [[Maquina]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---
**Categoria:** [[07_plantilles]]
**Relacionat:** [[00_arquitectura_tecnica_unificada]], [[00_INDEX]]
**Ancoratge de Seguretat:** [[00_INDEX]]
