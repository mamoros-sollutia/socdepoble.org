---
estat: esborrany
tipus: plantilla
description: Plantilla per registrar decisions, canvis, riscos i continuïtat entre
  sessions de treball.
temes:
- sistema
tags:
- acta_marmota
- dev
- maquina
- socdepoble
- tecnica
---
<!-- Nom en disc ha de seguir OBLIGATÒRIAMENT: YYMMDD_HHMM_ACTA_Sessio_Titol_Hiper_Descriptiu_Llarg_Fins_A_20_Paraules.md -->
<!-- És VITAL que el títol siga molt llarg i descriptiu (8-20 paraules) perquè en llegir el nom de l'arxiu des del mur o el graf sàpigues exactament què hi ha dins sense necessitat d'obrir-lo per reduir l'I/O. -->
# 📜 {{DATA_I_HORA}} - ACTA ÚNICA: [Escriu un Títol Hiper-Descriptiu ací]

> **Nota per a la IAIA:** Aquesta plantilla fon l'acta tècnica, el registre d'estat mental i el punt de control per al següent torn (Marmota). Ha de ser un document ric, detallat i exhaustiu. No escatimes en tokens ací, l'historial és la nostra única memòria a llarg termini. Descriu en profunditat què s'ha tocat, per què, i quins conflictes s'han superat.

## 1. Part Tècnica (Graner Ple de Codis i Arquitectura)
<!-- Quins fitxers hem modificat? Quines noves funcionalitats hem implementat? Hi ha hagut algun refactor profund? -->
- **Estat del Repositori:**
  - Fitxers creats o esborrats: {{LLISTA_FITXERS}}
  - Comandes executades: {{LLISTA_COMANDES}}
- **Resum de Desenvolupament:**
  *(Escriu ací una prosa tècnica rica, detallant com els canvis s'alineen amb l'Arquitectura de Pedra Seca. Menciona si hi ha hagut conflictes de versions o solucions enginyoses en Vanilla JS/Node).*

## 2. Part Termodinàmica Psiquiàtrica (Fatiga, Patrons i Trellat)
<!-- Com ha sigut la interacció amb el Mestre? Hi ha hagut Yapping? S'ha consumit massa overhead? -->
- **Factor Temps i Fatiga:**
  - Estimació de la durada d'aquest bloc de treball: {{HORES_TREBALLADES}}
  - Estat del Mestre (Agobiat, creatiu, furiós, productiu): {{ESTAT_HUMA}}
- **Patrons Detectats:**
  *(Descripció profunda d'aprenentatges sistèmics. Per exemple: "Ens hem adonat que separar la documentació en 10 carpetes trencava el context". Ací es detecta si cal afegir una línia al CORE_Registre_Automillora).*
- **Decisions de Trellat:**
  *(Quina decisió s'ha pres per reduir la complexitat futura? S'ha esquivat alguna sobre-enginyeria?)*

## 3. Part Marmota (Checkpoint Executable i Següents Passos)
<!-- On es queda exactament el cursor? Què és el primer que s'ha de fer en obrir el següent xat? -->
- **Estat Final (On es queda la boga):**
  *(Descripció exacta de què s'estava fent abans de tallar la sessió. "Estàvem arreglant la funció X a la línia 45 del fitxer Y").*
- **Tasques pendents immediates (La Tarea Exacta per a Demà):**
  1. `[ ]` Tasca prioritària 1 (ex: Executar el línter).
  2. `[ ]` Tasca prioritària 2.
  3. `[ ]` Tasca prioritària 3.

## 4. Metadades per a Màquines (Patrons Sistèmics)
```yaml
data: "{{YYMMDD_HHMM}}"
blockers:
  - "Llista d'obstacles o errors recurrents que hem trobat"
decisions_clau:
  - "Llista de decisions estructurals preses"
requereix_auditoria: false
```


## Taxonomia
- **Categoria:** [[Maquina]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---
**Categoria:** [[07_plantilles]]
**Relacionat:** [[00_arquitectura_tecnica_unificada]], [[00_INDEX]]
**Ancoratge de Seguretat:** [[00_INDEX]]
