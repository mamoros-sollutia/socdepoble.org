---
estat: canonic
tipus: plantilla
description: Plantilla mestra per definir una skill amb missió, gallets, regles i
  contracte d'eixida.
temes:
- sistema
tags:
- dev
- maquina
- skills
- socdepoble
- tecnica
---
# ⚙️ SDP SKILL MASTER TEMPLATE
**Nom de la Skill:** [Ex: Maquetador d'Esdeveniments Offline]
**Gallets d'Activació (Triggers):** "[[el_projecte|Sóc de Poble]]!"

## 1. PROPÒSIT I FILOSOFIA
[Descripció directa i robòtica de la missió de l'Agent. Ex: Generar llistats de targetes respectant l'espaiat i la PWA local-first].

## 2. 🚨 CODI PENAL ESTRICTE (Llista Negra d'Accions)
*La violació d'una sola norma suposa el fracàs de l'Agent:*
- [ ] **PROHIBIT TAILWIND ESTÈTIC:** Mai usaràs classes Tailwind per a colors, radis o ombres (`text-blue-500`, `rounded-3xl`). Usaràs classes semàntiques vinculades al diccionari `--sp-*`. Tailwind només maqueta l'espai (`flex`, `grid`, `gap`, `w-full`).
- [ ] **PROHIBIT L'ÚS DE FANTASMES:** No empraràs mai `<hr>`. La separació visual es fa amb jerarquia de títols.
- [ ] **PROHIBICIÓ WCAG (Mode Bancal):** Mai renderitzaràs text blanc sobre la variable `--sp-orange-100`.
- [ ] **PROHIBIDES LES CONSTANTS RIGIDES:** No faràs servir colors Hexadecimals directes en el CSS ni radis fixes (com `28px`); tot depén de `--sp-*`.
- [ ] **PROHIBIT JAVASCRIPT PER ANIMACIONS:** Cap transició ni interacció visual de Surar o Premut dependrà de JS.

## 3. ✅ CHECKLIST D'ENTREGA (Mode Bancal i Accessibilitat)
Abans de finalitzar la resposta, l'Agent ha de validar en silenci:
- [ ] Les àrees tàctils (botons/inputs) tenen un mínim de 48x48px o 56px d'alçada?
- [ ] Els textos descriptius base tenen com a mínim 16px per a evitar el zoom destructiu d'iOS?
- [ ] S'han implementat els estats termodinàmics requerits exclusivament en CSS (Surar, Premut, Sec)?
- [ ] La geometria respecta innegociablement `--sp-radius-main` (28px)?
- [ ] L'HTML generat és 100% semàntic sense dependre de classes CSS per al seu significat?

---


## Taxonomia
- **Categoria:** [[Maquina]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---
**Categoria:** [[07_plantilles]]
**Relacionat:** [[00_arquitectura_tecnica_unificada]], [[00_INDEX]]
**Ancoratge de Seguretat:** [[00_INDEX]]
