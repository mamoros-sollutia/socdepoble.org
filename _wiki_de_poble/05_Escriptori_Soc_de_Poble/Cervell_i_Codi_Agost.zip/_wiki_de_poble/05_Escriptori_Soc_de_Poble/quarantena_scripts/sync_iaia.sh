#!/bin/bash
# sync_iaia.sh - Sincronitzador de la IAIA MarIA (Pedra Seca)

echo "🏗️  Sincronitzant la IAIA MarIA cap a La Fortalesa de Pedra (Madrid)..."

# Assegurem que estem a l'arrel del projecte
cd "$(dirname "$0")"

# Creem un paquet amb el codi del bot i la Wiki de Poble
echo "📦 Empaquetant coneixement..."
tar --exclude='bot/node_modules' --exclude='bot/var' --exclude='bot/.env' --exclude='bot/.iaia_auth' -czf iaia_sync.tar.gz bot/ _wiki_de_poble/ tooling/

# Pujem el paquet a la VM
echo "🚀 Pujant a Google Cloud..."
gcloud compute scp iaia_sync.tar.gz iaia-maria-bot:/home/$USER/iaia/ --zone=europe-southwest1-a

# Ens connectem per descomprimir i reiniciar el cervell
echo "🧠 Reiniciant el cervell de la IAIA..."
gcloud compute ssh iaia-maria-bot --zone=europe-southwest1-a --command="cd /home/\$USER/iaia && tar -xzf iaia_sync.tar.gz && rm iaia_sync.tar.gz && cd bot && npm install --omit=dev --legacy-peer-deps && pm2 reload iaia-maria"

# Netegem
rm iaia_sync.tar.gz

echo "✅ Sincronització completada amb èxit! La IAIA ja té els coneixements nous."
