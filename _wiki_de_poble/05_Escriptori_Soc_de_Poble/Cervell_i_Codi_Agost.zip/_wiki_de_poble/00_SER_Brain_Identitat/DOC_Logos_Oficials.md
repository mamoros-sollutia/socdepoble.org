---
estat: canonic
tipus: document
description: Aquest document és la font de veritat dels logos oficials.
temes:
- sistema
tags:
- core
- genoma
- identitat
- socdepoble
---
# DOC Logos Oficials

## Regla

Aquest document és la font de veritat dels logos oficials.

Cap plantilla ha d’incrustar blocs repetits de logos. Les plantilles han d’enllaçar només:

`DOC_Logos_Oficials`

## Recursos Oficials

| Recurs | Ús | Ubicació |
|---|---|---|
| Logo principal [[el_projecte|Sóc de Poble]] | Capçaleres, portada, marca institucional | `{ruta_logo_principal}` |
| Isotip Mas | Icona PWA, favicon, avatars | `{ruta_isotip}` |
| Marca IAIA MarIA | Documents interns i agents | `{ruta_iaia}` |
| Cartell fundacional | Narrativa i presentacions | `{ruta_cartell}` |

## Prohibicions

1. No duplicar logos dins de plantilles.
2. No usar logos no aprovats.
3. No deformar proporcions.
4. No incrustar assets en base64 dins Markdown.
5. No inventar paletes fora d’Identitat_Visual.

## Sinapsis

- [[identitat_visual|Identitat_Visual]]
- [[PLANTILLA_ISO_SDP]]
- [[00_visio_i_pilars]]

## Taxonomia
- **Categoria:** [[Identitat]]
- **Etiquetes:** [[Graf]]


**Ancoratge de Seguretat:** [[00_INDEX]]


---

**Ancoratge de Seguretat:** [[00_INDEX]]