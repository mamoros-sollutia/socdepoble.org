---
estat: auditat
tipus: document
tags:
- socdepoble
---
# Memorial de Làpides

## 04_ARXIU_Documents_Historics/actes_arxivades/90_arxiu_historic
Làpida erigida per enllaç perdut a _wiki_de_poble/00_SER_Brain_Identitat/00_INDEX.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-1.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-2.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-3.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-4.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-1.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-2.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-3.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-4.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md

## les_petorretes
Làpida erigida per enllaç perdut a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/00_arquitectura_tecnica_unificada.md

## 02_ACTUAR_Maquina_Tecnica/plantilles/PLANTILLA_ISO_SDP
Làpida erigida per enllaç perdut a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/07_plantilles/00_plantilles.md

## 04_ARXIU_Documents_Historics/actes_arxivades/90_arxiu_historic
Làpida erigida per enllaç perdut a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/07_plantilles/00_plantilles.md

## les_petorretes
Làpida erigida per enllaç perdut a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/skills/AUDITORIA_CANONICA.md

## ^\
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## Target
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## ${d.a}
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## ${d.b}
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## enllaços
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## ...
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## FenceFantasma
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## B
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## Canari_Restore
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## test
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## resolve, reject
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 00_INDEX_ARXIU_SECUNDARI
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 04_ARXIU_Documents_Historics/actes_arxivades/90_arxiu_historic
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-1.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-2.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-3.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-4.jpg
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## les_petorretes
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md

## 02_ACTUAR_Maquina_Tecnica/plantilles/PLANTILLA_ISO_SDP
Làpida erigida per enllaç perdut a _wiki_de_poble/04_ARXIU_Documents_Historics/260719_1655_BUNDLE_Sistema_Operatiu_IAIA_MarIA_Complet.md
- [2026-07-19T17:48:02.940Z] Enllaç tancat a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-1.jpg)
- [2026-07-19T17:48:02.940Z] Enllaç tancat a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-2.jpg)
- [2026-07-19T17:48:02.940Z] Enllaç tancat a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-3.jpg)
- [2026-07-19T17:48:02.940Z] Enllaç tancat a _wiki_de_poble/00_SER_Brain_Identitat/el_projecte.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-4.jpg)
- [2026-07-19T17:48:03.011Z] Enllaç tancat a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-1.jpg)
- [2026-07-19T17:48:03.011Z] Enllaç tancat a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-2.jpg)
- [2026-07-19T17:48:03.011Z] Enllaç tancat a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-3.jpg)
- [2026-07-19T17:48:03.011Z] Enllaç tancat a _wiki_de_poble/01_SABER_Cultura_Coneixement/00_visio_i_pilars.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/assets/que-es-socdepoble-4.jpg)
- [2026-07-19T17:48:03.089Z] Enllaç tancat a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/00_arquitectura_tecnica_unificada.md (apuntava a: les_petorretes)
- [2026-07-19T17:48:03.183Z] Enllaç tancat a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/07_plantilles/00_plantilles.md (apuntava a: 02_ACTUAR_Maquina_Tecnica/plantilles/PLANTILLA_ISO_SDP)
- [2026-07-19T17:48:03.183Z] Enllaç tancat a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/07_plantilles/00_plantilles.md (apuntava a: 04_ARXIU_Documents_Historics/actes_arxivades/90_arxiu_historic)
- [2026-07-19T17:48:03.258Z] Enllaç tancat a _wiki_de_poble/02_ACTUAR_Maquina_Tecnica/skills/AUDITORIA_CANONICA.md (apuntava a: les_petorretes)
- [2026-07-19T17:48:03.339Z] Enllaç tancat a _wiki_de_poble/05_Escriptori_Soc_de_Poble/260715_0400_ACTA_SESSIO_Tancament_Gran_Auditoria.md (apuntava a: 00_INDEX_ARXIU_SECUNDARI)
- [2026-07-19T17:48:03.441Z] Enllaç tancat a _wiki_de_poble/05_Escriptori_Soc_de_Poble/260716_1300_ACTA_SESSIO_Problema_Sincronitzacio_Skills.md (apuntava a: 00_INDEX_ARXIU_SECUNDARI)
- [2026-07-19T17:48:03.524Z] Enllaç tancat a _wiki_de_poble/05_Escriptori_Soc_de_Poble/260719_0345_PROMPT_Auditoria_Suprema_Consell.md (apuntava a: 00_INDEX_ARXIU_SECUNDARI)
- [2026-07-19T17:48:03.607Z] Enllaç tancat a _wiki_de_poble/05_Escriptori_Soc_de_Poble/260719_0415_ACTA_SESSIO_La_Gran_Destillacio.md (apuntava a: 00_INDEX_ARXIU_SECUNDARI)
- [2026-07-19T17:48:03.695Z] Enllaç tancat a _wiki_de_poble/05_Escriptori_Soc_de_Poble/Claude/260719_0630_AUDITORIA_Fuita_Bancaria_Nucli_Mort_I_Constitucio_Triple_Trencada.md (apuntava a: 00_INDEX_ARXIU_SECUNDARI)
- [2026-07-19T17:48:03.776Z] Enllaç tancat a _wiki_de_poble/05_Escriptori_Soc_de_Poble/Claude/260719_0630_PATCH_Sutura_Imports_Nucli_I_Arrel_De_Wiki_Corregida.md (apuntava a: 00_INDEX_ARXIU_SECUNDARI)


---

**Ancoratge de Seguretat:** [[00_INDEX]]