import { useEffect } from 'react';
import { Navigate, useParams } from 'react-router-dom';
import { UniversalPage } from '../../components/universal/UniversalComponents';
import { useAppData } from '../../app/AppDataContext';
import { resolveItemPath } from '../../config/navigation';
import { renderPageHtml } from './detailRichText.jsx';
import { sanitizeHtml } from '../../utils/sanitize';

export default function PageDetailSection() {
  const { pageDetailLookup, t } = useAppData();
  const { slug } = useParams();
  const item = pageDetailLookup.get(String(slug));

  useEffect(() => {
    const main = document.querySelector('.app-main') || document.querySelector('soc-de-poble')?.shadowRoot?.querySelector('.app-main');
    if (main) main.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  }, [slug]);

  if (!item) {
    return <Navigate to="/mur" replace />;
  }

  const knownPath = resolveItemPath(item);
  if (knownPath && knownPath !== `/page/${slug}`) {
    return <Navigate to={knownPath} replace />;
  }

  return (
    <UniversalPage
      title={item.title || t('section.text.page', 'Pàgina')}
      subtitle={item.post_subtitle || item.author || ''}
      chrome="system"
      showLogos={true}
    >
      <div className="detail-page">
        <div className="detail-hero card">
          {Array.isArray(item.image_url) && item.image_url[0] ? (
            <div className="media-frame media-frame--contain detail-hero__media">
              <img src={item.image_url[0]} alt={item.title || 'Pàgina'} decoding="async" />
            </div>
          ) : null}
          <div className="card__body">
            <ul className="sp-card-labels" aria-label="Categories">
              <li className="sp-card-label sdp-badge-system">{item.type || t('section.text.page', 'page')}</li>
              {item.slug && <li className="sp-card-label sdp-badge-tag">{item.slug}</li>}
            </ul>
            <h2 className="card__title">{item.title || t('section.text.page', 'Pàgina')}</h2>
            {item.post_subtitle ? <p className="section-item-card__subtitle">{item.post_subtitle}</p> : null}
            <article
              className="detail-content"
              dangerouslySetInnerHTML={{ __html: sanitizeHtml(renderPageHtml(item.content || '')) }}
            />
          </div>
        </div>
      </div>
    </UniversalPage>
  );
}
