import { useEffect, useRef, useState } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Image as ImageIcon, Lock, FileText } from 'lucide-react';
import { useNotes, etiquetesDeNota } from './NotesContext';
import NotesToolbar from './NotesToolbar';
import UniversalEditorShell from '../../components/universal/UniversalEditorShell';
import { sanitizeHtml } from '../../utils/sanitize.js';

export default function NotesEditor() {
  const { activeNote, saveNoteField, setLocalNoteField, noteFolders, t } = useNotes();
  const [isEditingImage, setIsEditingImage] = useState(false);
  const [isEditingLogo, setIsEditingLogo] = useState(false);
  const timeoutRef = useRef(null);
  const pendingSaveRef = useRef({ id: null, content: null });
  const currentNoteRef = useRef({ id: null, title: '', subtitle: '', lead: '' });
  const fileInputRef = useRef(null);
  const logoInputRef = useRef(null);

  const LIMIT_HERO = 512 * 1024;

  const triaImatge = (e) => {
    const fitxer = e.target.files?.[0];
    e.target.value = '';
    if (!fitxer) return;
    if (!fitxer.type.startsWith('image/')) return alert('Només imatges, de moment.');
    if (fitxer.size > LIMIT_HERO) return alert('La imatge passa de 512 KB. Redueix-la abans.');
    const lector = new FileReader();
    lector.onload = () => { 
      saveNoteField(activeNote.id, 'heroImage', String(lector.result)); 
      setIsEditingImage(false); 
    };
    lector.onerror = () => alert("No s'ha pogut llegir el fitxer.");
    lector.readAsDataURL(fitxer);
  };

  const triaLogo = (e) => {
    const fitxer = e.target.files?.[0];
    e.target.value = '';
    if (!fitxer) return;
    if (!fitxer.type.startsWith('image/')) return alert('Només imatges, de moment.');
    if (fitxer.size > LIMIT_HERO) return alert('La imatge passa de 512 KB. Redueix-la abans.');
    const lector = new FileReader();
    lector.onload = () => { 
      saveNoteField(activeNote.id, 'logoImage', String(lector.result)); 
      setIsEditingLogo(false); 
    };
    lector.onerror = () => alert("No s'ha pogut llegir el fitxer.");
    lector.readAsDataURL(fitxer);
  };

  const handleDeleteHero = () => {
    if (!window.confirm('Esborrar definitivament la imatge de capçalera?')) return;
    saveNoteField(activeNote.id, 'heroImage', ''); 
    setIsEditingImage(false);
  };

  const handleDeleteLogo = () => {
    if (!window.confirm('Esborrar definitivament el logotip?')) return;
    saveNoteField(activeNote.id, 'logoImage', ''); 
    setIsEditingLogo(false);
  };

  if (currentNoteRef.current.id !== activeNote?.id) {
    currentNoteRef.current = {
      id: activeNote?.id,
      title: activeNote?.title || '',
      subtitle: activeNote?.subtitle || '',
      lead: activeNote?.lead || ''
    };
  }

  const editor = useEditor({
    extensions: [StarterKit.configure({ heading: { levels: [2, 3, 4] } })],
    content: activeNote?.content || '',
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      pendingSaveRef.current = { id: activeNote?.id, content: html };
      setLocalNoteField(activeNote?.id, 'content', html);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        saveNoteField(activeNote?.id, 'content', html);
        pendingSaveRef.current = { id: null, content: null };
      }, 800);
    },
    editorProps: {
      attributes: {
        class: 'editor-content page-content sdp-text-cos sdp-prose'
      },
    },
  });

  useEffect(() => {
    if (!editor || editor.isDestroyed || !activeNote) return;
    try {
      if (editor.getHTML() !== activeNote.content) {
        editor.commands.setContent(activeNote.content || '');
      }
    } catch (err) {
      console.warn('Editor sync skipped (Fast Refresh / not ready)', err);
    }
  }, [activeNote?.id, editor]);

  // Guardat segur al canviar de nota o desmuntar
  useEffect(() => {
    const currentId = activeNote?.id;
    return () => {
      if (timeoutRef.current && pendingSaveRef.current.id === currentId) {
        clearTimeout(timeoutRef.current);
        saveNoteField(currentId, 'content', pendingSaveRef.current.content);
        pendingSaveRef.current = { id: null, content: null };
      }
    };
  }, [activeNote?.id]);

  // Reset image editing state when switching notes
  useEffect(() => {
    setIsEditingImage(false);
    setIsEditingLogo(false);
  }, [activeNote?.id]);

  if (!activeNote) {
    return (
      <section className="notes-column notes-column--editor">
        <div className="chat-empty">
          <FileText size={64} />
          <h2 className="section-title">{t('section.notes.open', 'Obre un solc')}</h2>
        </div>
      </section>
    );
  }

  return (
    <UniversalEditorShell
      topBar={<NotesToolbar editor={editor} />}
      titleText={activeNote.title || 'Sense Títol'}
      heroImage={activeNote.heroImage}
      logoImage={activeNote.logoImage}
      isPublished={activeNote.isPublished}
      formattedTime={activeNote.formattedTime}
      formattedDate={activeNote.formattedDate}
      titleHtml={currentNoteRef.current.title}
      subtitleHtml={currentNoteRef.current.subtitle}
      leadHtml={currentNoteRef.current.lead}
      onSaveField={(field, value) => saveNoteField(activeNote.id, field, value)}
      onLocalChange={(field, value) => setLocalNoteField(activeNote.id, field, value)}
      labels={etiquetesDeNota(activeNote, noteFolders, {})}
    >
      <div className="editor-tiptap-container">
        <EditorContent editor={editor} />
      </div>
    </UniversalEditorShell>
  );
}
