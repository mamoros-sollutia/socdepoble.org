from bs4 import BeautifulSoup
import re

with open("src/html/mapa.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, 'html.parser')

# 1. Update the search bar width
# Find the div with "CERCA AL MAPA..."
search_input = soup.find('input', placeholder="CERCA AL MAPA...")
if search_input:
    search_bar_container = search_input.parent
    overlay_container = search_bar_container.parent
    # The overlay_container currently has style="position: absolute; top: 16px; left: 16px; right: 16px; z-index: 10;"
    # Let's change it to not have 'right: 16px;' and have a max-width.
    overlay_style = overlay_container.get('style', '')
    overlay_style = overlay_style.replace('right: 16px;', '')
    overlay_style += ' max-width: 320px;'
    overlay_container['style'] = overlay_style

# 2. Replace the "Pols del Territori" block
pols_header = soup.find('h2', string=re.compile("Pols del Territori"))
if pols_header:
    # Get the parent block: <div class="sdp-flex sdp-items-center sdp-justify-between sdp-my-8">
    pols_container = pols_header.parent.parent
    
    # Create the new H2 and lead paragraph
    new_html = """
    <div class="sdp-text-center sdp-mt-8 sdp-mb-6">
        <h2>Geolocalitzacions</h2>
        <p class="lead">Totes les cards estan geolocalitzades ja que qualsevol usuari publica des d'un poble. Ací podeu veure totes les publicacions de qualsevol tipus mesclades ja que estan filtrades per geolocalització, i podeu buscar o triar per events, mur, mercat, pobles i altres etiquetes que se'ns acudisquen en el futur.</p>
    </div>
    """
    new_soup = BeautifulSoup(new_html, 'html.parser')
    pols_container.replace_with(new_soup)

with open("src/html/mapa.html", "w", encoding="utf-8") as f:
    f.write(str(soup))

print("mapa.html updated.")
