import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Current block has the inline styles and H2 / H3 / p
pattern = re.compile(r'<div class="sdp-text-center sdp-mb-6">\s*<h2 style="color: var\(--sdp-secondary-600\); margin-top: var\(--sdp-space-2\);">L\'Alacantí</h2>\s*<h3 class="sdp-mt-6" style="margin-bottom: var\(--sdp-space-2\);">La Torre de les Maçanes</h3>\s*<p style="max-width: 600px; margin: 0 auto; color: var\(--sdp-pedra-600\);">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l\'Alacantí, a la comarca històrica de la Foia de Xixona.</p>\s*</div>')

new_block = """<div class="sdp-text-center sdp-mb-6">
  <h2>La Torre de les Maçanes</h2>
  <p class="lead">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l'Alacantí, a la comarca històrica de la Foia de Xixona.</p>
</div>"""

if pattern.search(html):
    html = pattern.sub(new_block, html)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Fixed headers to H2 + lead in gentdelatorre.html")
else:
    print("Pattern not found. Checking current content of gentdelatorre.html")

