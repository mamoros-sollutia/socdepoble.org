import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace <div class="tab"> to <h3 class="tab sdp-m-0"> to remove bottom margin
html = html.replace('<div class="tab">General</div>', '<h3 class="tab sdp-m-0">General</h3>')
html = html.replace('<div class="tab">Arxiu i Documents</div>', '<h3 class="tab sdp-m-0">Arxiu i Documents</h3>')
html = html.replace('<div class="tab">El Meu Eixam</div>', '<h3 class="tab sdp-m-0">El Meu Eixam</h3>')
html = html.replace('<div class="tab">Ajustos</div>', '<h3 class="tab sdp-m-0">Ajustos</h3>')

# Also handle the active one just in case (though I removed it previously)
html = html.replace('<div class="tab active">General</div>', '<h3 class="tab active sdp-m-0">General</h3>')

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Changed tabs to H3.")
