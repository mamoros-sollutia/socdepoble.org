import re

with open('disseny_pedra_seca.html', 'r', encoding='utf-8') as f:
    content = f.read()

# The current structure:
# <header class="page-title">
# <!-- Logotip Mode Clar -->
# <img alt="Logotip Sóc de Poble" class="page-title-logo light-only" src="assets/img/logo-socdepoble-rect-negre.svg"/>
# <!-- Logotip Mode Fosc -->
# <img alt="Logotip Sóc de Poble" class="page-title-logo dark-only" src="https://socdepoble.org/assets/system/ui/logo-socdepoble-rect-blanc.svg"/>
# <h1>Disseny Pedra Seca</h1>
# <h2 class="sdp-mt-2">Sistema oficial de disseny per a Sóc de Poble.</h2>
# <p class="sdp-mt-4">Inclou la Targeta Mestra, els colors oficials, i tots els elements preparats, inclús els skills i scripts, per a que qualsevol IA puga entendre este sistema i reproduir-lo.</p>
# </header>

old_html = """<h1>Disseny Pedra Seca</h1>
<h2 class="sdp-mt-2">Sistema oficial de disseny per a Sóc de Poble.</h2>
<p class="sdp-mt-4">Inclou la Targeta Mestra, els colors oficials, i tots els elements preparats, inclús els skills i scripts, per a que qualsevol IA puga entendre este sistema i reproduir-lo.</p>
</header>"""

new_html = """<h1>Disseny Pedra Seca</h1>
</header>
<div class="sdp-text-center sdp-mt-6 sdp-mb-12">
  <h2 class="sdp-mt-2 sdp-mb-4">Sistema oficial de disseny per a Sóc de Poble.</h2>
  <p class="lead" style="max-width: 800px; margin: 0 auto;">Inclou la Targeta Mestra, els colors oficials, i tots els elements preparats, inclús els skills i scripts, per a que qualsevol IA puga entendre este sistema i reproduir-lo.</p>
</div>"""

content = content.replace(old_html, new_html)

with open('disseny_pedra_seca.html', 'w', encoding='utf-8') as f:
    f.write(content)

