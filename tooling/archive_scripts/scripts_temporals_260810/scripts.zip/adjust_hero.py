import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace aspect ratio
html = html.replace('aspect-ratio: 6/1;', 'aspect-ratio: 5/1;')

# Replace object-position
html = html.replace('object-position: center;"', 'object-position: center 30%;"')

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Updated hero image aspect ratio to 5/1 and object position to center 30%")
