import re

js_path = "src/js/pedra-seca.js"
with open(js_path, "r", encoding="utf-8") as f:
    js = f.read()

# I will find the second occurrence and remove it.
tab_script_start = "// Tabs System (Collapsible)"
first_idx = js.find(tab_script_start)
second_idx = js.find(tab_script_start, first_idx + 10)

if second_idx != -1:
    # Find the end of the second block. It's a }); that aligns with the block.
    # The block ends with "  });\n\n\n      // 1. FAB Button (Scroll to top)"
    end_idx = js.find("// 1. FAB Button", second_idx)
    if end_idx != -1:
        # Go back to just before the newlines
        js = js[:second_idx] + js[end_idx:]
        with open(js_path, "w", encoding="utf-8") as f:
            f.write(js)
        print("Removed second block.")
    else:
        print("Couldn't find end of second block.")
else:
    print("Couldn't find second block.")
