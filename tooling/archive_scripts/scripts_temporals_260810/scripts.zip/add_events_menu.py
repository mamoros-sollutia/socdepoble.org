import os
import glob
import re

html_dir = "src/html"
html_files = glob.glob(os.path.join(html_dir, "*.html"))

nav_pobles = '<a class="nav-item" href="pobles.html">Pobles</a>'
nav_events = '<a class="nav-item" href="events.html">Events</a>'

for file_path in html_files:
    with open(file_path, "r", encoding="utf-8") as f:
        html = f.read()

    if nav_pobles in html and nav_events not in html:
        new_html = html.replace(nav_pobles, f"{nav_pobles}\n<a class=\"nav-item\" href=\"events.html\">Events</a>")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(new_html)
        print(f"Added Events to {os.path.basename(file_path)}")

