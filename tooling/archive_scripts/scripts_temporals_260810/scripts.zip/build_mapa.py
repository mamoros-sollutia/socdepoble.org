from bs4 import BeautifulSoup
import re

# Read disseny.html to get all cards
with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    soup_disseny = BeautifulSoup(f, 'html.parser')

cards_to_include = []
for article in soup_disseny.find_all('article', class_=re.compile('sp-card')):
    # Skip "Gent de la Torre" author or title "La Torre de les Maçanes"
    h1 = article.find('h1')
    author = article.find('div', class_='sp-card-author-name')
    
    if author and "Gent de la Torre" in author.text:
        continue # Skip this card
    if h1 and "La Torre de les Maçanes" in h1.text:
        continue # Also skip just in case
        
    # Exclude the "Disseny Pedra Seca" card? The user said "todas las cards que tienes porque todas tienen un nombre de usuario y un pueblo". 
    # Let's check the first card "Disseny Pedra Seca" -> author "Sóc de Poble". It has a user and a town. So include it.
    # Exclude minimal card? It has "Exemple de card mínima" -> no user/town. 
    # Wait, the user said "van todas las cards que tienes... menos Gent de la torre". 
    # Let's just include all except Gent de la Torre, or manually filter if they lack author.
    if not author:
        continue # Skip cards without authors (like minimal card)
        
    cards_to_include.append(article)

# Read pobles.html as a template
with open("src/html/pobles.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, 'html.parser')

# Update title
title = soup.find('title')
if title: title.string = "Mapa | Sóc de Poble"

# Update Header
header = soup.find('header', class_='page-title')
if header:
    h1 = header.find('h1')
    if h1: h1.string = "Mapa"
    label = header.find('span', class_='label-orange')
    if label: label.string = "MAPA"

# Clean up main
main_tag = soup.find('main', class_='app-main')
for sibling in header.find_next_siblings():
    sibling.extract()

map_html = """
<div class="sdp-p-4 sdp-p-md-8">
    <div style="border-radius: 8px; overflow: hidden; margin-bottom: 32px; border: 1px solid var(--sdp-vora); height: 600px; background: #e5e3df; position: relative;">
        <!-- Embedded Google Maps as a placeholder for the interactive map -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24962.308709339322!2d-0.4357709503173828!3d38.606775618783425!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd6227a92fb4bce3%3A0x63351221b6d92582!2sLa%20Torre%20de%20les%20Ma%C3%A7anes%2C%20Alicante!5e0!3m2!1ses!2ses!4v1715426189345!5m2!1ses!2ses" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        
        <!-- Fake overlay controls from screenshot to make it look like the design -->
        <div style="position: absolute; top: 16px; left: 16px; right: 16px; z-index: 10;">
            <div style="display: flex; gap: 8px; background: white; padding: 8px 16px; border-radius: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); align-items: center;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input type="text" placeholder="CERCA AL MAPA..." style="border: none; outline: none; flex: 1; font-weight: bold; color: var(--sdp-pedra-700);">
                <div style="background: var(--sdp-primary-500); border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; color: white;">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 9h16M4 15h16"></path></svg>
                </div>
            </div>
            <div style="display: flex; gap: 8px; margin-top: 12px; overflow-x: auto; padding-bottom: 8px; scrollbar-width: none;">
                <span style="background: white; padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 6px; white-space: nowrap;"><span style="color: var(--sdp-primary-500);">●</span> Events</span>
                <span style="background: white; padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 6px; white-space: nowrap;"><span style="color: var(--sdp-primary-500);">●</span> Mur</span>
                <span style="background: white; padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 6px; white-space: nowrap;"><span style="color: var(--sdp-primary-500);">●</span> Mercat</span>
                <span style="background: white; padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 6px; white-space: nowrap;"><span style="color: var(--sdp-primary-500);">●</span> Pobles</span>
                <span style="background: white; padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 6px; white-space: nowrap;"><span style="color: var(--sdp-primary-500);">●</span> Comerços i empreses</span>
                <span style="background: white; padding: 6px 12px; border-radius: 20px; font-weight: bold; font-size: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 6px; white-space: nowrap;"><span style="color: var(--sdp-primary-500);">●</span> Associacions</span>
            </div>
        </div>
    </div>
    
    <div class="sdp-flex sdp-items-center sdp-justify-between sdp-my-8">
        <div class="sdp-flex sdp-items-center sdp-gap-2">
            <svg style="color: var(--sdp-primary-500);" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
            </svg>
            <h2 style="margin:0; font-size: 1.5rem; color: var(--sdp-pedra-900);">Pols del Territori</h2>
        </div>
        <div style="color: var(--sdp-pedra-500); font-size: 0.85rem; font-weight: 700;">24 REGISTRES</div>
    </div>
    
    <div class="sdp-card-grid" id="mapa-grid">
    </div>
</div>
"""

new_content_soup = BeautifulSoup(map_html, 'html.parser')
grid = new_content_soup.find(id='mapa-grid')

for card in cards_to_include:
    grid.append(card)

main_tag.append(new_content_soup)

with open("src/html/mapa.html", "w", encoding="utf-8") as f:
    f.write(str(soup))

print("Created mapa.html with map iframe and requested cards.")
