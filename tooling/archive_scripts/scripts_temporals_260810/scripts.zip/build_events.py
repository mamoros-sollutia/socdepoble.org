import re

with open("src/html/pobles.html", "r", encoding="utf-8") as f:
    html = f.read()

# I want to replace everything inside <main class="app-main"> ... </main>
# and put my custom HTML.
# Wait, pobles.html has the black bar <header class="bar-black"> inside <main>. I should keep that.
# Then there is <header class="bar-blue">. I'll replace everything after <header class="bar-black">...</header>

# Find where bar-black ends
end_black_bar = html.find("</header>", html.find('<header class="bar-black"')) + len("</header>")

header_part = html[:end_black_bar]
footer_part = html[html.rfind('</main>'):]

# Ensure we fix the title
header_part = header_part.replace('<title>Els Pobles', '<title>Events')

custom_content = """
<!-- BARRA DE CERCA TARONJA (Com al disseny) -->
<header class="bar-orange sdp-flex sdp-items-center" style="padding: var(--sdp-space-2) var(--sdp-space-4); justify-content: space-between;">
    <div class="sdp-flex sdp-items-center sdp-gap-4" style="flex: 1;">
        <button class="btn-icon-orange" onclick="window.history.back()" style="color: white; border-color: rgba(255,255,255,0.3);"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m15 18-6-6 6-6"/></svg></button>
        <button class="btn-icon-orange" onclick="window.history.forward()" style="color: white; border-color: rgba(255,255,255,0.3);"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg></button>
        <div style="flex: 1; max-width: 800px; position: relative;">
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: white;"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg>
            <input type="text" placeholder="CERCA A L'AGENDA..." style="width: 100%; padding: 8px 12px 8px 40px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.5); background: rgba(255,255,255,0.1); color: white; outline: none; font-weight: bold;">
        </div>
    </div>
    <div class="sdp-flex sdp-items-center sdp-gap-2">
        <button class="btn-icon-orange" style="color: white; border-color: rgba(255,255,255,0.3);"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg></button>
        <button class="btn-icon-orange" style="background: rgba(255,255,255,0.2); color: white; border-color: rgba(255,255,255,0.5);"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg></button>
    </div>
</header>

<div class="sdp-p-4 sdp-p-md-8" style="background: #fff; min-height: calc(100vh - 120px);">
    <!-- CALENDARI TOOLBAR -->
    <div class="sdp-flex sdp-items-center sdp-justify-between sdp-mb-4" style="flex-wrap: wrap; gap: 16px;">
        <div class="sdp-flex sdp-items-center sdp-gap-2">
            <button style="padding: 6px 12px; background: var(--sdp-pedra-600); color: white; border-radius: 4px; border: none; cursor: pointer;">&lt;</button>
            <button style="padding: 6px 12px; background: var(--sdp-pedra-600); color: white; border-radius: 4px; border: none; cursor: pointer;">&gt;</button>
            <button style="padding: 6px 16px; background: var(--sdp-pedra-500); color: white; border-radius: 4px; border: none; cursor: pointer; font-weight: bold;">Avui</button>
            <button style="padding: 6px 16px; background: var(--sdp-pedra-500); color: white; border-radius: 4px; border: none; cursor: pointer; font-weight: bold;">G-Cal / Config</button>
            <button style="padding: 6px 16px; background: var(--sdp-pedra-700); color: white; border-radius: 4px; border: none; cursor: pointer; font-weight: bold;">+ Nou Esdeveniment</button>
        </div>
        
        <h2 style="color: var(--sdp-primary-500); margin: 0; font-size: 1.5rem; text-align: center; flex: 1;">agost del 2026</h2>
        
        <div class="sdp-flex sdp-items-center" style="background: var(--sdp-pedra-800); border-radius: 4px; overflow: hidden;">
            <button style="padding: 8px 16px; background: white; color: var(--sdp-pedra-900); border: none; font-weight: bold; cursor: pointer;">Mes</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">Setmana</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">4 dies</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">Dia</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">Agenda</button>
        </div>
    </div>
    
    <!-- CALENDARI GRID -->
    <div style="border: 1px solid var(--sdp-vora); border-radius: 8px; overflow: hidden; margin-bottom: 32px;">
        <!-- Headers -->
        <div style="display: grid; grid-template-columns: repeat(7, 1fr); background: var(--sdp-primary-50); border-bottom: 1px solid var(--sdp-vora); text-align: center; padding: 12px 0; font-weight: bold; font-size: 0.9rem;">
            <div>DL.</div><div>DT.</div><div>DC.</div><div>DJ.</div><div>DV.</div><div>DS.</div><div>DG.</div>
        </div>
        <!-- Dies (5 setmanes) -->
        <div style="display: grid; grid-template-columns: repeat(7, 1fr); grid-auto-rows: minmax(100px, auto);">
            <!-- Week 1 -->
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">27</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">28</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">29</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">30</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">31</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">1</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">2</div>
            
            <!-- Week 2 -->
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">3</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">4</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">5</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">6</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">7</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">8</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">9</div>
            
            <!-- Week 3 -->
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold; background: var(--sdp-primary-50); position: relative;">
                <div style="background: var(--sdp-primary-500); color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; position: absolute; right: 8px; top: 8px;">10</div>
            </div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">11</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">12</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">13</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">14</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">15</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">16</div>
            
            <!-- Week 4 -->
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">17</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">18</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">19</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">20</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">21</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">22</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">23</div>
            
            <!-- Week 5 -->
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">24</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">25</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">26</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">27</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">28</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">29</div>
            <div style="padding: 8px; text-align: right; font-weight: bold;">30</div>
            
            <!-- Week 6 (partial) -->
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">31</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">1</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">2</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">3</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">4</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">5</div>
            <div style="border-top: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">6</div>
        </div>
    </div>
    
    <!-- ANCORES DE MEMÒRIA RECENT -->
    <div class="sdp-flex sdp-items-center sdp-justify-between sdp-mb-4" style="border-bottom: 1px solid var(--sdp-vora); padding-bottom: 8px;">
        <h3 class="sdp-flex sdp-items-center sdp-gap-2" style="color: var(--sdp-primary-500); margin: 0; font-size: 1.25rem;">
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            Àncores de Memòria Recent
        </h3>
        <div style="font-size: 0.8rem; font-weight: bold; color: var(--sdp-pedra-500);">2 REGISTRES</div>
    </div>
    
    <div class="sdp-card-grid sdp-mt-4">
        
        <!-- CARD: El Viatjant -->
        <article class="sp-card">
            <header class="sp-card-header" style="background: var(--sdp-primary-500); color: white; border-bottom: none;">
                <div class="sp-card-author" style="color: white;">
                    <div style="width: 32px; height: 32px; background: var(--sdp-primary-200); color: var(--sdp-primary-800); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.8rem;">EV</div>
                    <div class="sp-card-author-info">
                        <div class="sp-card-author-name" style="color: white; font-size: 1.1rem; font-weight: 800;">El Viatjant</div>
                        <div class="sp-card-author-location" style="color: rgba(255,255,255,0.8);"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 12px; height: 12px; display: inline-block; margin-right: 4px;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>Alcoi</div>
                    </div>
                </div>
                <div class="sp-card-meta sdp-gap-8" style="color: white;">
                    <div style="text-align: right; font-size: 0.8rem; font-weight: bold; line-height: 1.2;">
                        <div>11:00</div>
                        <div>15/2/2026</div>
                    </div>
                </div>
            </header>
            <div class="sp-card-media">
                <!-- Using a gradient placeholder similar to the sunset in screenshot -->
                <div style="width: 100%; aspect-ratio: 16/9; background: linear-gradient(to bottom, #0ea5e9, #f59e0b);"></div>
            </div>
        </article>

        <!-- CARD: El Cronista -->
        <article class="sp-card">
            <header class="sp-card-header" style="background: var(--sdp-primary-500); color: white; border-bottom: none;">
                <div class="sp-card-author" style="color: white;">
                    <div style="width: 32px; height: 32px; background: var(--sdp-primary-200); color: var(--sdp-primary-800); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.8rem;">EC</div>
                    <div class="sp-card-author-info">
                        <div class="sp-card-author-name" style="color: white; font-size: 1.1rem; font-weight: 800;">El Cronista</div>
                        <div class="sp-card-author-location" style="color: rgba(255,255,255,0.8);"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 12px; height: 12px; display: inline-block; margin-right: 4px;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>Benifallim</div>
                    </div>
                </div>
                <div class="sp-card-meta sdp-gap-8" style="color: white;">
                    <div style="text-align: right; font-size: 0.8rem; font-weight: bold; line-height: 1.2;">
                        <div>21:00</div>
                        <div>13/2/2026</div>
                    </div>
                </div>
            </header>
            <div class="sp-card-media">
                <div style="width: 100%; aspect-ratio: 16/9; background: linear-gradient(to bottom, #0ea5e9, #f59e0b);"></div>
            </div>
        </article>
    </div>
</div>
"""

final_html = header_part + custom_content + footer_part

with open("src/html/events.html", "w", encoding="utf-8") as f:
    f.write(final_html)

print("Generated events.html")
