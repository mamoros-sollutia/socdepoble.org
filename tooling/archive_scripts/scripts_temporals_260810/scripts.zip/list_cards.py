from bs4 import BeautifulSoup
import re

with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, 'html.parser')

cards = soup.find_all('article', class_=re.compile('sp-card'))
for idx, card in enumerate(cards):
    h1 = card.find('h1')
    title = h1.text.strip() if h1 else "No H1"
    print(f"Card {idx}: {title}")
