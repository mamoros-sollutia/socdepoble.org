import re

javi_path = "src/html/javillinares.html"
gent_path = "src/html/gentdelatorre.html"
pobles_path = "src/html/pobles.html"

with open(javi_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace titles
html = re.sub(r'<title>.*?</title>', '<title>Gent de La Torre | Sóc de Poble</title>', html)

# Replace HERO image and aspect ratio
html = html.replace('aspect-ratio: 1/1;', 'aspect-ratio: 21/9;')
html = html.replace('https://socdepoble.org/assets/uploads/gent/javi-llinares/avatars/javi-llinares-perfil-1200px.jpg', 'https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg')

# Fix orange bar author
html = html.replace('<div class="sp-card-author-name">Javi Llinares</div>', '<div class="sp-card-author-name">Gent de La Torre</div>')
html = html.replace('<div class="sp-card-author-location">La Torre de les Maçanes</div>', '<div class="sp-card-author-location">@gentdelatorre</div>')

# Fix page title header
html = html.replace('<h1>Javi Llinares</h1>', '<h1>Gent de La Torre</h1>')
html = html.replace('<span class="sp-card-label label-orange">MESTRE</span>', '<span class="sp-card-label label-orange">POBLE</span>')
html = html.replace('<span class="sp-card-label label-blue">LA TORRE DE LES MAÇANES</span>', '<span class="sp-card-label label-blue">L\'ALACANTÍ</span>')

# Fix entradilla
html = html.replace('<h2>L\'arquitecte del Poble</h2>', '<h2>La Torre de les Maçanes</h2>')
html = html.replace('<p class="lead">Construint el futur del poble, pedra a pedra.</p>', '<p class="lead">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l\'Alacantí, a la comarca històrica de la Foia de Xixona.</p>')

with open(gent_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Created gentdelatorre.html")

# Now update pobles.html to link to gentdelatorre.html
with open(pobles_path, "r", encoding="utf-8") as f:
    p_html = f.read()

p_html = p_html.replace('href="#" title="Obrir poble"', 'href="gentdelatorre.html" title="Obrir poble"')
p_html = p_html.replace('href="#" title="Anar a gent de la torre"', 'href="gentdelatorre.html" title="Anar a gent de la torre"')

with open(pobles_path, "w", encoding="utf-8") as f:
    f.write(p_html)
print("Updated links in pobles.html")
