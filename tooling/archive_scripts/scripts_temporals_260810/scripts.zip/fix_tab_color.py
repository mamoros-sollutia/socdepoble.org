import re

css_path = "src/css/pedra-seca.css"
with open(css_path, "r", encoding="utf-8") as f:
    css = f.read()

# Replace the color in .tab to let H3 (or any other tag) dictate the base color
old_tab = ".tab { padding: var(--sdp-space-3) var(--sdp-space-6); font-weight: 700; color: var(--sdp-pedra-500); cursor: pointer; border-bottom: 3px solid transparent; white-space: nowrap; transition: color var(--sdp-t), border-color var(--sdp-t); }"
new_tab = ".tab { padding: var(--sdp-space-3) var(--sdp-space-6); font-weight: 700; cursor: pointer; border-bottom: 3px solid transparent; white-space: nowrap; transition: color var(--sdp-t), border-color var(--sdp-t); }"

if old_tab in css:
    css = css.replace(old_tab, new_tab)
    with open(css_path, "w", encoding="utf-8") as f:
        f.write(css)
    print("Fixed .tab color.")
else:
    print("Could not find the exact .tab string.")
