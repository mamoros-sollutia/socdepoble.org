import re

def get_first_card(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        html = f.read()
    start = html.find('<article class="sp-card">')
    if start == -1: return ""
    depth = 0
    i = start
    while i < len(html):
        if html[i:].startswith('<article'):
            depth += 1
            i += 8
        elif html[i:].startswith('</article>'):
            depth -= 1
            i += 10
            if depth == 0:
                return html[start:i]
        else:
            i += 1
    return ""

def get_persona_card():
    html_path = "src/html/disseny.html"
    with open(html_path, "r", encoding="utf-8") as f:
        html = f.read()
    start = html.find('<h4>20.4 Targeta Mestra: Persona</h4>')
    card_start = html.find('<article class="sp-card">', start)
    if card_start == -1: return ""
    depth = 0
    i = card_start
    while i < len(html):
        if html[i:].startswith('<article'):
            depth += 1
            i += 8
        elif html[i:].startswith('</article>'):
            depth -= 1
            i += 10
            if depth == 0:
                return html[card_start:i]
        else:
            i += 1
    return ""

card_mur = get_first_card("src/html/mur.html")
card_mercat = get_first_card("src/html/mercat.html")
card_persona = get_persona_card()

gent_path = "src/html/gentdelatorre.html"
with open(gent_path, "r", encoding="utf-8") as f:
    gent_html = f.read()

# Add Quadre de Comandament title
if 'Quadre de Comandament' not in gent_html:
    gent_html = gent_html.replace(
        '<h3 class="sdp-mb-4" style="color: var(--sdp-primary-500);">Resum d\'Activitat</h3>',
        '<h3 class="sdp-mb-4" style="color: var(--sdp-primary-500);">Quadre de Comandament</h3>\n    <h4 class="sdp-mb-4" style="color: var(--sdp-secondary-500);">Resum d\'Activitat</h4>'
    )
    gent_html = gent_html.replace(
        '<h3 class="sdp-mb-4 sdp-mt-8" style="color: var(--sdp-primary-500);">El Meu Arxiu</h3>',
        '<h4 class="sdp-mb-4 sdp-mt-8" style="color: var(--sdp-secondary-500);">El Meu Arxiu</h4>'
    )

# Insert the grid
# Find the end of the upload section:
upload_end = gent_html.find('<!-- END UPLOAD AREA -->')
if upload_end == -1:
    upload_end = gent_html.find('</div>\n  </div>\n</main>') # Fallback

if upload_end != -1 and 'Publicacions de La Torre' not in gent_html:
    # Find the closing </div> of the tab-content
    tab_close = gent_html.find('</div>', upload_end) + 6
    grid_html = f"""
    <h3 class="sdp-mb-4 sdp-mt-8" style="color: var(--sdp-primary-500);">Publicacions de La Torre</h3>
    <div class="sp-card-grid">
{card_mur}
{card_mercat}
{card_persona}
    </div>
"""
    gent_html = gent_html[:tab_close] + grid_html + gent_html[tab_close:]

with open(gent_path, "w", encoding="utf-8") as f:
    f.write(gent_html)
print("Grid added to gentdelatorre.html")
