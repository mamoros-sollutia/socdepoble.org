import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# The grid was added at the very end of the file.
# We know </body> and </html> are at lines 457, 458.
# Lines 459 to EOF contain the grid.
html_close_idx = -1
for i, line in enumerate(lines):
    if line.strip() == "</html>":
        html_close_idx = i
        break

if html_close_idx != -1 and html_close_idx < len(lines) - 1:
    grid_lines = lines[html_close_idx + 1:]
    
    # We will remove them from the end
    lines = lines[:html_close_idx + 1]
    
    # And we find the closing </article> to insert before it
    article_close_idx = -1
    for i in range(html_close_idx, -1, -1):
        if lines[i].strip() == "</article>":
            article_close_idx = i
            break
            
    if article_close_idx != -1:
        # Insert before </article>
        lines = lines[:article_close_idx] + grid_lines + lines[article_close_idx:]
        
        with open(html_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        print("Moved grid inside <article> successfully.")
    else:
        print("Error: Could not find </article>")
else:
    print("Error: Could not find grid at the end of file after </html>")

