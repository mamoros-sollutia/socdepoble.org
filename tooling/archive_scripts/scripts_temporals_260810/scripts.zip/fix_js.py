import re

js_path = "src/js/pedra-seca.js"
with open(js_path, "r", encoding="utf-8") as f:
    js = f.read()

# Remove all occurrences of the injected tab script
tab_script_start = "// Tabs System (Collapsible)"
tab_script_end = "});\n    });\n  });"

while True:
    start_idx = js.find(tab_script_start)
    if start_idx == -1:
        break
    end_idx = js.find(tab_script_end, start_idx)
    if end_idx != -1:
        end_idx += len(tab_script_end)
        # Also remove any trailing newlines
        while end_idx < len(js) and js[end_idx] == '\n':
            end_idx += 1
        js = js[:start_idx] + js[end_idx:]
    else:
        break

# Now inject it ONCE safely, at the end of DOMContentLoaded
good_script = """
  // Tabs System (Collapsible)
  document.querySelectorAll('.tabs').forEach(tabsContainer => {
    let tabContent = tabsContainer.nextElementSibling;
    while(tabContent && !tabContent.classList.contains('tab-content')) {
      tabContent = tabContent.nextElementSibling;
    }
    if (!tabContent) return;

    // Default state
    const activeTab = tabsContainer.querySelector('.tab.active');
    if (!activeTab) {
      tabContent.style.display = 'none';
    } else {
      tabContent.style.display = 'block';
    }

    const allTabs = tabsContainer.querySelectorAll('.tab');
    allTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        // Prevent default if it's a link or something
        e.preventDefault();
        
        if (tab.classList.contains('active')) {
          tab.classList.remove('active');
          tabContent.style.display = 'none';
        } else {
          allTabs.forEach(t => t.classList.remove('active'));
          tab.classList.add('active');
          tabContent.style.display = 'block';
        }
      });
    });
  });
"""

insert_idx = js.rfind("});") # End of DOMContentLoaded or similar.
# Wait, let's just insert it before the closing of the first DOMContentLoaded
doc_ready = "document.addEventListener('DOMContentLoaded', () => {"
if doc_ready in js:
    js = js.replace(doc_ready, doc_ready + good_script)

with open(js_path, "w", encoding="utf-8") as f:
    f.write(js)
print("JS Fixed.")
