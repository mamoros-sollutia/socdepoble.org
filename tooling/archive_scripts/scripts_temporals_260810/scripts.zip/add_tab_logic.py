import re

js_path = "src/js/pedra-seca.js"
with open(js_path, "r", encoding="utf-8") as f:
    js = f.read()

tab_script = """
  // Tabs System (Collapsible)
  document.querySelectorAll('.tabs').forEach(tabsContainer => {
    // Find the next sibling that is a tab-content
    let tabContent = tabsContainer.nextElementSibling;
    while(tabContent && !tabContent.classList.contains('tab-content')) {
      tabContent = tabContent.nextElementSibling;
    }

    if (!tabContent) return;

    // Default state: Hide tab-content if no tab is active
    const activeTab = tabsContainer.querySelector('.tab.active');
    if (!activeTab) {
      tabContent.style.display = 'none';
    } else {
      tabContent.style.display = 'block';
    }

    tabsContainer.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        if (tab.classList.contains('active')) {
          // If clicking the active tab, collapse it
          tab.classList.remove('active');
          tabContent.style.display = 'none';
        } else {
          // Activate this tab and show content
          tabsContainer.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
          tab.classList.add('active');
          tabContent.style.display = 'block';
          
          // Here we would normally switch the content based on the tab,
          // but for now we just show the single .tab-content container.
        }
      });
    });
  });
"""

if "Tabs System (Collapsible)" not in js:
    js = js.replace("document.addEventListener('DOMContentLoaded', () => {", "document.addEventListener('DOMContentLoaded', () => {\n" + tab_script)
    with open(js_path, "w", encoding="utf-8") as f:
        f.write(js)
    print("Added tab logic to pedra-seca.js")
else:
    print("Tab logic already exists.")
