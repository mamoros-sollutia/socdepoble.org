import re

# 1. Fix CSS
css_path = "src/css/pedra-seca.css"
with open(css_path, "r", encoding="utf-8") as f:
    css = f.read()

old_tab = ".tab { padding: var(--sdp-space-3) var(--sdp-space-6); font-weight: 700; cursor: pointer; border-bottom: 3px solid transparent; white-space: nowrap; transition: color var(--sdp-t), border-color var(--sdp-t); }"
new_tab = ".tab { font-size: 1.05rem; color: var(--sdp-secondary-500); padding: var(--sdp-space-3) var(--sdp-space-6); font-weight: 700; cursor: pointer; border-bottom: 3px solid transparent; white-space: nowrap; transition: color var(--sdp-t), border-color var(--sdp-t); }"

if old_tab in css:
    css = css.replace(old_tab, new_tab)
    with open(css_path, "w", encoding="utf-8") as f:
        f.write(css)

# 2. Fix JS
js_path = "src/js/pedra-seca.js"
with open(js_path, "r", encoding="utf-8") as f:
    js = f.read()

# Remove all Tabs System blocks
tab_script_start = "// Tabs System (Collapsible)"
while True:
    start_idx = js.find(tab_script_start)
    if start_idx == -1:
        break
    
    # find the end of the block - it ends with } after some listener
    # since we might have botched it, let's just use regex to remove everything from // Tabs System to the next //
    next_comment = js.find("//", start_idx + 10)
    if next_comment == -1:
        js = js[:start_idx]
    else:
        # Actually this is risky. Let's just find "document.querySelectorAll('.tabs').forEach" and manually remove the block.
        pass

# It's safer to just rewrite the file based on a backup or manually parse it.
# Let's just see what is in the file right now.
