with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    disseny = f.read()

def get_card(keyword):
    # Find keyword
    idx = disseny.find(keyword)
    if idx == -1:
        return "<!-- NOT FOUND -->"
    
    # Search backwards for <article
    start_idx = disseny.rfind('<article class="sp-card', 0, idx)
    
    # Search forwards for </article>
    end_idx = disseny.find('</article>', idx) + len('</article>')
    
    return disseny[start_idx:end_idx]

festa_card = get_card("Festa Major del Poble")
paella_card = get_card("On fem la paella popular?")
transport_card = get_card("Necessite transport a Alcoi")

# Modify transport_card to add date
badge_html = """<div class="sp-card-calendar-badge">
    <div class="sp-card-calendar-badge__dia">11</div>
    <div class="sp-card-calendar-badge__mes">AGOST</div>
</div>
"""
transport_card = transport_card.replace("<h1>Necessite transport a Alcoi</h1>", badge_html + "<h1>Necessite transport a Alcoi</h1>")

with open("src/html/pobles.html", "r", encoding="utf-8") as f:
    pobles = f.read()

pobles = pobles.replace("<title>Pobles | Sóc de Poble</title>", "<title>Events | Sóc de Poble</title>")

import re
header_match = re.search(r'(<header class="page-title[^>]*>.*?)(<h1>Pobles</h1>)(.*?<span class="sp-card-label label-orange">)(POBLES)(</span>.*?</header>)', pobles, re.DOTALL)
if header_match:
    new_header = header_match.group(1) + "<h1>Events</h1>" + header_match.group(3) + "EVENTS" + header_match.group(5)
    pobles = pobles[:header_match.start()] + new_header + pobles[header_match.end():]

page_title_end = pobles.find('</header>', pobles.find('<header class="page-title')) + len('</header>')

with open("src/html/events.html", "r", encoding="utf-8") as f:
    old_events = f.read()
cal_start = old_events.find('<!-- CALENDARI TOOLBAR -->')
cal_end = old_events.find('<!-- ANCORES DE MEMÒRIA RECENT -->')
calendar_html = old_events[cal_start:cal_end] if cal_start != -1 else "<!-- CALENDAR MISSING -->"

h2_html = """
<div class="sdp-text-center sdp-my-8">
    <h2>Esdeveniments</h2>
    <p class="lead">Cerca esdeveniments prop de les teues comarques.</p>
</div>
<div class="sdp-card-grid">
"""
grid_content = festa_card + "\n" + paella_card + "\n" + transport_card + "\n</div>"

main_end = pobles.find('</main>')
footer = pobles[main_end:]

new_main_content = calendar_html + h2_html + grid_content + "\n"

final_html = pobles[:page_title_end] + "\n<div class=\"sdp-p-4 sdp-p-md-8\">\n" + new_main_content + "</div>\n" + footer

with open("src/html/events.html", "w", encoding="utf-8") as f:
    f.write(final_html)

print("Rebuilt events.html with exact cards.")
