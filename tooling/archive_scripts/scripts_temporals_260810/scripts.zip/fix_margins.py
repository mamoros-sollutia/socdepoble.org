import re

with open('disseny_pedra_seca.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Fix header.page-title base margin-bottom
content = re.sub(
    r'(header\.page-title\s*\{[^}]*margin:\s*0\s+var\(--sdp-space-10\)\s+)var\(--sdp-space-16\)(;)',
    r'\1var(--sdp-space-8)\2',
    content
)

# 2. Fix media queries for header.page-title
content = re.sub(
    r'(header\.page-title\s*\{.*?margin:\s*0\s+var\(--sdp-space-4\)\s+)var\(--sdp-space-10\)(;)',
    r'\1var(--sdp-space-5)\2',
    content
)
content = re.sub(
    r'(header\.page-title\s*\{.*?margin-bottom:\s*)var\(--sdp-space-8\)(;)',
    r'\1var(--sdp-space-4)\2',
    content
)
content = re.sub(
    r'(header\.page-title\s*\{.*?margin:\s*0\s+12px\s+)28px(;)',
    r'\114px\2',
    content
)

# 3. Fix the container H2 margin (sdp-mt-6 sdp-mb-12 -> sdp-mt-2 sdp-mb-6)
content = content.replace(
    '<div class="sdp-text-center sdp-mt-6 sdp-mb-12">',
    '<div class="sdp-text-center sdp-mt-2 sdp-mb-6">'
)

with open('disseny_pedra_seca.html', 'w', encoding='utf-8') as f:
    f.write(content)

