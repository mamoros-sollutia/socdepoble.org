file_path = "src/html/gentdelatorre.html"
with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# delete lines 560 to 608 (1-indexed, so 559 to 608 in 0-indexed)
# Wait, let's verify if lines 559 is exactly <article class="sp-card">
start_idx = 559
end_idx = 608

if "<article class=\"sp-card\">" in lines[start_idx] and "Gent de la Torre" in lines[start_idx + 7]:
    del lines[start_idx:end_idx]
    with open(file_path, "w", encoding="utf-8") as f:
        f.writelines(lines)
    print("Deleted card successfully.")
else:
    print(f"Mismatch at index {start_idx}: {lines[start_idx]}")
