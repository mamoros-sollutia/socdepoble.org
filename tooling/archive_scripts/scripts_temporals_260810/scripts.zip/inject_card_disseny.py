import re

disseny_path = "src/html/disseny.html"
pobles_path = "src/html/pobles.html"

with open(pobles_path, "r", encoding="utf-8") as f:
    pobles_html = f.read()

# Extract the card from pobles
card_start = pobles_html.find('<article class="sp-card">')
card_end = pobles_html.find('</article>', card_start) + len('</article>')
card_html = pobles_html[card_start:card_end]

with open(disseny_path, "r", encoding="utf-8") as f:
    disseny_html = f.read()

# We need to insert after 20.4 Targeta Mestra: Persona.
# We'll find 20.5 Targeta Mestra: Enquesta and insert before it.
# And renumber 20.5 to 20.6, 20.6 to 20.7, etc.

# First, renumber the existing ones
disseny_html = disseny_html.replace('20.9 Targeta Mestra: Bàsica', '20.10 Targeta Mestra: Bàsica')
disseny_html = disseny_html.replace('20.8 Targeta Mestra: Avís (Emergència)', '20.9 Targeta Mestra: Avís (Emergència)')
disseny_html = disseny_html.replace('20.7 Targeta Mestra: Lloc', '20.8 Targeta Mestra: Lloc')
disseny_html = disseny_html.replace('20.6 Targeta Mestra: Ajuda', '20.7 Targeta Mestra: Ajuda')
disseny_html = disseny_html.replace('20.5 Targeta Mestra: Enquesta', '20.6 Targeta Mestra: Enquesta')

injection_point = disseny_html.find('<h4>20.6 Targeta Mestra: Enquesta</h4>')

if injection_point != -1:
    new_section = """
<h4>20.5 Targeta Mestra: Pobles</h4>
<p class="sdp-mb-4 sdp-text-center">Aquesta variant de la Targeta Mestra s'utilitza per a representar nuclis poblacionals. Utilitza la mateixa estructura base, però adapta el bloc d'autor per a representar la identitat col·lectiva: el nom de l'autor mostra "Gent de [Poble]" i la ubicació mostra la comarca corresponent.</p>
<div class="sdp-card-grid sdp-mb-8">
""" + card_html + """
</div>
"""
    new_html = disseny_html[:injection_point] + new_section + disseny_html[injection_point:]
    
    with open(disseny_path, "w", encoding="utf-8") as f:
        f.write(new_html)
    print("Successfully injected Targeta Mestra: Pobles into disseny.html")
else:
    print("Could not find injection point")
