with open("src/html/events.html", "r", encoding="utf-8") as f:
    html = f.read()

# We need to find the start of the first grid, which we injected:
# <div class="sdp-card-grid">
grid_start = html.find('<div class="sdp-card-grid">')

# Wait, the old content is after our injected grid. Our injected grid ends with </div>
# But it's easier to just find the three cards we want, and then discard everything until </main>

# Let's find </main>
main_end = html.rfind('</main>')
footer = html[main_end:]

# We can just extract everything up to <div class="sdp-card-grid">
# Then re-add the 3 specific cards we extracted previously.
import re

with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    disseny = f.read()

festa_match = re.search(r'<article class="sp-card sp-card--calendari">.*?Festa Major del Poble.*?</article>', disseny, re.DOTALL)
festa_card = festa_match.group(0)

paella_match = re.search(r'<article class="sp-card">.*?On fem la paella popular\?.*?</article>', disseny, re.DOTALL)
paella_card = paella_match.group(0)

transport_match = re.search(r'<article class="sp-card">.*?Necessite transport a Alcoi.*?</article>', disseny, re.DOTALL)
transport_card = transport_match.group(0)
badge_html = """<div class="sp-card-calendar-badge">
    <div class="sp-card-calendar-badge__dia">11</div>
    <div class="sp-card-calendar-badge__mes">AGOST</div>
</div>
"""
transport_card = transport_card.replace("<h1>Necessite transport a Alcoi</h1>", badge_html + "<h1>Necessite transport a Alcoi</h1>")

new_grid = '<div class="sdp-card-grid">\n' + festa_card + "\n" + paella_card + "\n" + transport_card + "\n</div>\n"

# Replace everything from <div class="sdp-card-grid"> up to </main> with just our new_grid
new_html = html[:grid_start] + new_grid + "</div>\n" + footer

with open("src/html/events.html", "w", encoding="utf-8") as f:
    f.write(new_html)

print("Cleaned up events grid.")
