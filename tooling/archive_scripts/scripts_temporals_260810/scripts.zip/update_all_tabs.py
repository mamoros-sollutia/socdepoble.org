import os
import glob

html_dir = "src/html"
html_files = glob.glob(os.path.join(html_dir, "*.html"))

for file_path in html_files:
    with open(file_path, "r", encoding="utf-8") as f:
        html = f.read()

    changed = False
    
    # Change div tabs to h3 tabs
    if '<div class="tab"' in html or '<div class="tab active"' in html:
        # We need to replace things carefully so we don't break content.
        # It's better to just regex replace <div class="tab[^"]*">Text</div>
        import re
        
        def tab_replacer(match):
            cls = match.group(1)
            text = match.group(2)
            # Remove active
            cls = cls.replace('active', '').strip()
            # Ensure sdp-m-0 is there
            if 'sdp-m-0' not in cls:
                cls += ' sdp-m-0'
            cls = cls.strip()
            return f'<h3 class="{cls}">{text}</h3>'
            
        new_html = re.sub(r'<div class="(tab[^"]*)">(.*?)</div>', tab_replacer, html)
        
        if new_html != html:
            html = new_html
            changed = True
            
    if changed:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"Updated tabs in {os.path.basename(file_path)}")

