from bs4 import BeautifulSoup

# 1. Get the correct 'Necessite transport' card from events.html
with open("src/html/events.html", "r", encoding="utf-8") as f:
    events_soup = BeautifulSoup(f, 'html.parser')

correct_transport_card = None
for article in events_soup.find_all('article', class_='sp-card'):
    h1 = article.find('h1')
    if h1 and "Necessite transport a Alcoi" in h1.text:
        correct_transport_card = article
        break

if not correct_transport_card:
    print("Error: Could not find transport card in events.html")
    exit(1)

# 2. Update the card in disseny.html
with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    disseny_soup = BeautifulSoup(f, 'html.parser')

for article in disseny_soup.find_all('article', class_='sp-card'):
    h1 = article.find('h1')
    if h1 and "Necessite transport a Alcoi" in h1.text:
        article.replace_with(BeautifulSoup(str(correct_transport_card), 'html.parser'))
        break

with open("src/html/disseny.html", "w", encoding="utf-8") as f:
    f.write(str(disseny_soup))

# 3. Update the card in gentdelatorre.html
with open("src/html/gentdelatorre.html", "r", encoding="utf-8") as f:
    gent_soup = BeautifulSoup(f, 'html.parser')

for article in gent_soup.find_all('article', class_='sp-card'):
    h1 = article.find('h1')
    if h1 and "Necessite transport a Alcoi" in h1.text:
        article.replace_with(BeautifulSoup(str(correct_transport_card), 'html.parser'))
        break

# Now get the complete grid from gentdelatorre.html
gent_grid = gent_soup.find('div', class_='sdp-card-grid')

with open("src/html/gentdelatorre.html", "w", encoding="utf-8") as f:
    f.write(str(gent_soup))

# 4. Copy the complete grid to mapa.html
with open("src/html/mapa.html", "r", encoding="utf-8") as f:
    mapa_soup = BeautifulSoup(f, 'html.parser')

mapa_grid = mapa_soup.find('div', class_='sdp-card-grid')
if mapa_grid and gent_grid:
    mapa_grid.replace_with(BeautifulSoup(str(gent_grid), 'html.parser'))

with open("src/html/mapa.html", "w", encoding="utf-8") as f:
    f.write(str(mapa_soup))

print("Cards synced successfully.")
