import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace HERO image
html = html.replace('https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg', 'https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/P_20161028_153325_SRES.jpg')

# The second occurrence was for the HERO image (the first one might have been replaced already).
# Let's make sure the hero image is replaced:
html = re.sub(r'(<div class="hero-image".*?<img alt="Gent de La Torre" src=")[^"]+(")', r'\1https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/P_20161028_153325_SRES.jpg\2', html)

# In the orange bar, replace the GD placeholder with the avatar image
avatar_html = '<img alt="Gent de La Torre" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/gentdelatorre-logo-bn-q.png" style="border-radius: 50%; object-fit: cover; background: white;"/>'

html = re.sub(r'<div class="sp-card-avatar sdp-flex sdp-items-center sdp-justify-center".*?>GD</div>', avatar_html, html)

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Images replaced in gentdelatorre.html")
