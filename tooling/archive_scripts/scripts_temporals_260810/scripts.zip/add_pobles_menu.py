import os

html_dir = "src/html"
target = '<a class="nav-item" href="mercat.html">Mercat</a>\n<a class="nav-item" href="disseny.html">Disseny</a>'
replacement = '<a class="nav-item" href="mercat.html">Mercat</a>\n<a class="nav-item" href="pobles.html">Pobles</a>\n<a class="nav-item" href="disseny.html">Disseny</a>'

target_no_newline = '<a class="nav-item" href="mercat.html">Mercat</a><a class="nav-item" href="disseny.html">Disseny</a>'
replacement_no_newline = '<a class="nav-item" href="mercat.html">Mercat</a>\n<a class="nav-item" href="pobles.html">Pobles</a>\n<a class="nav-item" href="disseny.html">Disseny</a>'

for filename in os.listdir(html_dir):
    if filename.endswith(".html"):
        filepath = os.path.join(html_dir, filename)
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
        
        # Check if the target is in the file
        if target in content:
            new_content = content.replace(target, replacement)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(new_content)
            print(f"Updated {filename}")
        else:
            print(f"Target not found in {filename} (maybe spacing is different)")
            # Let's try a regex approach just in case
            import re
            pattern = re.compile(r'(<a class="nav-item" href="mercat\.html">Mercat</a>)\s*(<a class="nav-item" href="disseny\.html">Disseny</a>)')
            if pattern.search(content):
                new_content = pattern.sub(r'\1\n<a class="nav-item" href="pobles.html">Pobles</a>\n\2', content)
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(new_content)
                print(f"Updated {filename} (via regex)")

