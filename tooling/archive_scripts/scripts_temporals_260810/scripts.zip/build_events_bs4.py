from bs4 import BeautifulSoup

# Read disseny.html
with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    soup_disseny = BeautifulSoup(f, 'html.parser')

# Extract the exactly requested cards by finding their H1 text
festa_card = None
paella_card = None
transport_card = None

for article in soup_disseny.find_all('article', class_='sp-card'):
    h1 = article.find('h1')
    if h1:
        if "Festa Major del Poble" in h1.text:
            festa_card = article
        elif "On fem la paella popular?" in h1.text:
            paella_card = article
        elif "Necessite transport a Alcoi" in h1.text:
            transport_card = article

# Modify transport_card
if transport_card:
    badge_html = """<div class="sp-card-calendar-badge">
    <div class="sp-card-calendar-badge__dia">11</div>
    <div class="sp-card-calendar-badge__mes">AGOST</div>
</div>
"""
    badge_soup = BeautifulSoup(badge_html, 'html.parser')
    h1_tag = transport_card.find('h1')
    if h1_tag:
        h1_tag.insert_before(badge_soup)

# Build the layout
with open("src/html/pobles.html", "r", encoding="utf-8") as f:
    soup_pobles = BeautifulSoup(f, 'html.parser')

# Update Title
title = soup_pobles.find('title')
if title: title.string = "Events | Sóc de Poble"

# Update Header (H1 and Orange label)
header = soup_pobles.find('header', class_='page-title')
if header:
    h1 = header.find('h1')
    if h1: h1.string = "Events"
    label = header.find('span', class_='label-orange')
    if label: label.string = "EVENTS"

# Remove all content inside main after the header
main_tag = soup_pobles.find('main', class_='app-main')

# We want to keep everything up to the <header class="page-title">
# Then we remove the rest inside <main> and append our own.
# A safe way is to find the node after <header class="page-title"> and replace it all.
for sibling in header.find_next_siblings():
    sibling.extract()

# Create the new content wrapper
new_content_html = """
<div class="sdp-p-4 sdp-p-md-8">
    <!-- CALENDARI TOOLBAR i GRID -->
    <div class="sdp-flex sdp-items-center sdp-justify-between sdp-mb-4" style="flex-wrap: wrap; gap: 16px;">
        <div class="sdp-flex sdp-items-center sdp-gap-2">
            <button style="padding: 6px 12px; background: var(--sdp-pedra-600); color: white; border-radius: 4px; border: none; cursor: pointer;">&lt;</button>
            <button style="padding: 6px 12px; background: var(--sdp-pedra-600); color: white; border-radius: 4px; border: none; cursor: pointer;">&gt;</button>
            <button style="padding: 6px 16px; background: var(--sdp-pedra-500); color: white; border-radius: 4px; border: none; cursor: pointer; font-weight: bold;">Avui</button>
            <button style="padding: 6px 16px; background: var(--sdp-pedra-500); color: white; border-radius: 4px; border: none; cursor: pointer; font-weight: bold;">G-Cal / Config</button>
            <button style="padding: 6px 16px; background: var(--sdp-pedra-700); color: white; border-radius: 4px; border: none; cursor: pointer; font-weight: bold;">+ Nou Esdeveniment</button>
        </div>
        
        <h2 style="color: var(--sdp-primary-500); margin: 0; font-size: 1.5rem; text-align: center; flex: 1;">agost del 2026</h2>
        
        <div class="sdp-flex sdp-items-center" style="background: var(--sdp-pedra-800); border-radius: 4px; overflow: hidden;">
            <button style="padding: 8px 16px; background: white; color: var(--sdp-pedra-900); border: none; font-weight: bold; cursor: pointer;">Mes</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">Setmana</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">4 dies</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">Dia</button>
            <button style="padding: 8px 16px; background: transparent; color: white; border: none; cursor: pointer;">Agenda</button>
        </div>
    </div>
    
    <div style="border: 1px solid var(--sdp-vora); border-radius: 8px; overflow: hidden; margin-bottom: 32px;">
        <div style="display: grid; grid-template-columns: repeat(7, 1fr); background: var(--sdp-primary-50); border-bottom: 1px solid var(--sdp-vora); text-align: center; padding: 12px 0; font-weight: bold; font-size: 0.9rem;">
            <div>DL.</div><div>DT.</div><div>DC.</div><div>DJ.</div><div>DV.</div><div>DS.</div><div>DG.</div>
        </div>
        <div style="display: grid; grid-template-columns: repeat(7, 1fr); grid-auto-rows: minmax(100px, auto);">
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">27</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">28</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">29</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">30</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">31</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">1</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">2</div>
            
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">3</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">4</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">5</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">6</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">7</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">8</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">9</div>
            
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold; background: var(--sdp-primary-50); position: relative;">
                <div style="background: var(--sdp-primary-500); color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; position: absolute; right: 8px; top: 8px;">10</div>
            </div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">11</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">12</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">13</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">14</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">15</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">16</div>
            
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">17</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">18</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">19</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">20</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">21</div>
            <div style="border-right: 1px solid var(--sdp-vora); border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">22</div>
            <div style="border-bottom: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">23</div>
            
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">24</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">25</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">26</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">27</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">28</div>
            <div style="border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">29</div>
            <div style="padding: 8px; text-align: right; font-weight: bold;">30</div>
            
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; font-weight: bold;">31</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">1</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">2</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">3</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">4</div>
            <div style="border-top: 1px solid var(--sdp-vora); border-right: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">5</div>
            <div style="border-top: 1px solid var(--sdp-vora); padding: 8px; text-align: right; color: var(--sdp-pedra-400);">6</div>
        </div>
    </div>
    
    <div class="sdp-text-center sdp-my-8">
        <h2>Esdeveniments</h2>
        <p class="lead">Cerca esdeveniments prop de les teues comarques.</p>
    </div>
    
    <div class="sdp-card-grid" id="events-grid">
    </div>
</div>
"""

new_content_soup = BeautifulSoup(new_content_html, 'html.parser')
grid = new_content_soup.find(id='events-grid')

if festa_card: grid.append(festa_card)
if paella_card: grid.append(paella_card)
if transport_card: grid.append(transport_card)

main_tag.append(new_content_soup)

with open("src/html/events.html", "w", encoding="utf-8") as f:
    f.write(str(soup_pobles))

print("BeautifulSoup rewrite done.")
