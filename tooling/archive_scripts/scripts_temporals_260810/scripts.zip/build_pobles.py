import re

html_path = "src/html/pobles.html"

with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Update meta tags and title
html = re.sub(r'<title>.*?</title>', '<title>Pobles | Sóc de Poble</title>', html)
html = html.replace('<h1>Mur de Sóc de Poble</h1>', '<h1>Pobles</h1>')
html = html.replace('<span class="sp-card-label label-orange">MUR</span>', '<span class="sp-card-label label-orange">POBLES</span>')
html = html.replace('<h2>El pols del nostre poble en temps real</h2>', '<h2>Nodes i territori</h2>')
html = html.replace('<p class="lead">Descobreix tot el que passa a La Torre de les Maçanes. Anuncis, esdeveniments, memòria i molt més.</p>', '<p class="lead">Cerca pobles, gent i territoris de la nostra geografia.</p>')

# Prepare the card HTML
card_html = """
<article class="sp-card">
<a class="sp-card-link-overlay" href="#" title="Obrir poble"></a>
<!-- 4. BARRA TARONJA -->
<header class="sp-card-header bar-orange">
<a class="sp-card-author-link" href="#" title="Anar a gent de la torre">
<div class="sp-card-author">
<div class="sp-card-avatar sdp-flex sdp-items-center sdp-justify-center" style="background: var(--sdp-color-orange-800); color: white; font-weight: bold; font-size: 14px;">GD</div>
<div class="sp-card-author-info">
<div class="sp-card-author-name">Gent de la Torre</div>
<div class="sp-card-author-location">L'Alacantí</div>
</div>
</div>
</a>
<div class="sp-card-meta sdp-gap-8">
<button class="btn-date-time" title="Veure l'activitat" style="color: white; opacity: 0.9;">
<span>06:07</span><span>2/2/2026</span>
</button>
</div>
</header>
<div class="sp-card-media">
<img alt="La Torre de les Maçanes" src="../assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"/>
</div>
<div class="sp-card-body">
<h1>La Torre de les Maçanes</h1>
<h2 class="sdp-text-blue-600 sdp-mb-4" style="margin-top:0">L'Alacantí</h2>
<p class="sp-card-text">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l'Alacantí, a la comarca històrica de la Foia de Xixona.</p>
<div class="sdp-text-center sdp-mt-6">
<a href="#" class="sdp-text-orange-600 sdp-font-bold sdp-text-sm">Llegir l'article sencer a Wikipedia ↗</a>
<div class="sdp-font-bold sdp-text-orange-600 sdp-mt-2" style="letter-spacing: 1px;">LLEGIR MÉS</div>
</div>
<div class="sp-card-copyright sdp-mt-4 sdp-text-center sdp-text-stone-400" style="font-size: 0.65rem;">© WIKIPEDIA / WIKIMEDIA COMMONS (CC BY-SA)</div>
</div>
<footer class="sp-card-footer bar-blue">
<div class="sp-card-actions">
<button class="sp-card-action" title="Traduir">
<svg class="icon" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><use href="#icon-6"></use></svg>
</button>
<button class="sp-card-action" title="Comentar">
<svg class="icon" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><use href="#icon-7"></use></svg>
</button>
<button class="sp-card-action" title="Compartir">
<svg class="icon" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><use href="#icon-8"></use></svg>
</button>
</div>
<button class="sp-card-connect" title="Connectar" onclick="window.location.href='connectar.html'">+ CONNECTAR</button>
</footer>
</article>
"""

# Find grid start
grid_start = html.find('<div class="sdp-card-grid sdp-mb-8">')
grid_end = html.find('</div>\n    </article>', grid_start)

if grid_start != -1 and grid_end != -1:
    before = html[:grid_start + len('<div class="sdp-card-grid sdp-mb-8">\n')]
    after = html[grid_end:]
    
    new_html = before + (card_html * 6) + after
    
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(new_html)
    print("pobles.html modified successfully.")
else:
    print("Could not find grid boundaries.")
