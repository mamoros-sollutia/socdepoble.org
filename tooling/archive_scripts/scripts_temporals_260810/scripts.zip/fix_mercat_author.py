import re

html_path = "src/html/mercat.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace the first card's author block
wrong_author = """<a class="sp-card-author-link" href="javillinares.html" title="Anar al perfil de l'autor">
<div class="sp-card-author">
<img alt="Javi Llinares" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/uploads/gent/javi-llinares/avatars/javi-llinares-perfil-1200px.jpg" style="border-radius: 50%; object-fit: cover;"/>
<div class="sp-card-author-info">
<div class="sp-card-author-name">Javi Llinares</div>
<div class="sp-card-author-location">La Torre de les Maçanes</div>
</div>
</div>
</a>"""

right_author = """<a class="sp-card-author-link" href="#" title="Anar al perfil de l'autor">
<div class="sp-card-author">
<img alt="Sóc de Poble" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/system/ui/logo-socdepoble-cuadrat-verd.svg"/>
<div class="sp-card-author-info">
<div class="sp-card-author-name">Sóc de Poble</div>
<div class="sp-card-author-location">La Torre de les Maçanes</div>
</div>
</div>
</a>"""

if wrong_author in html:
    html = html.replace(wrong_author, right_author)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Fixed author in mercat.html")
else:
    print("Could not find the exact string to replace. Checking via regex.")
    html = re.sub(
        r'<a class="sp-card-author-link" href="javillinares\.html" title="Anar al perfil de l\'autor">\s*<div class="sp-card-author">\s*<img alt="Javi Llinares" class="sp-card-avatar sdp-p-0" src="[^"]+" style="border-radius: 50%; object-fit: cover;"/>\s*<div class="sp-card-author-info">\s*<div class="sp-card-author-name">Javi Llinares</div>\s*<div class="sp-card-author-location">La Torre de les Maçanes</div>\s*</div>\s*</div>\s*</a>',
        right_author,
        html
    )
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Tried to fix via regex in mercat.html")

