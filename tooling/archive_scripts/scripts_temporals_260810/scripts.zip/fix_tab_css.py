import re

css_path = "src/css/pedra-seca.css"
with open(css_path, "r", encoding="utf-8") as f:
    css = f.read()

old_tab = ".tab { font-size: 1.05rem; color: var(--sdp-secondary-500); padding: var(--sdp-space-3) var(--sdp-space-6); font-weight: 700; cursor: pointer; border-bottom: 3px solid transparent; white-space: nowrap; transition: color var(--sdp-t), border-color var(--sdp-t); }"
new_tab = ".tab { font-size: 1rem; color: var(--sdp-secondary-500); padding: var(--sdp-space-3) var(--sdp-space-6); font-weight: 700; cursor: pointer; border-bottom: 3px solid transparent; white-space: nowrap; transition: color var(--sdp-t), border-color var(--sdp-t); }"

if old_tab in css:
    css = css.replace(old_tab, new_tab)
    with open(css_path, "w", encoding="utf-8") as f:
        f.write(css)
    print("Changed font-size to 1rem")
else:
    print("Could not find the exact string to replace.")

