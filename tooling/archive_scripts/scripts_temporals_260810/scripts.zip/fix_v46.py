import re

with open('/Users/javillinares/Documents/Antigravity/Som de Poble/socdepoble.org/disseny_pedra_seca.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Fix the missing sidebar selector
content = re.sub(r'/\* ── 3\. COLUMNA 1 · SIDEBAR ────────────────────────────────────── \*/\n\{', 
                 '/* ── 3. COLUMNA 1 · SIDEBAR ────────────────────────────────────── */\nnav.app-sidebar {', content)
content = re.sub(r'/\* L\'últim bloc \(menú\) absorbeix l\'alçada restant i fa scroll propi \*/\n> div:last-child \{',
                 '/* L\'últim bloc (menú) absorbeix l\'alçada restant i fa scroll propi */\nnav.app-sidebar > div:last-child {', content)

# 2. Fix empty .step rules
content = re.sub(r'\n\.step\.active \n\.step\.current \n\n\.step:not\(\.active\):not\(\.current\) \n', '\n', content)

# 3. Clean up the utilities block in <head>
utils_cleaned = """/* ── 9. UTILITATS SDP-* ─────────────────────────────────────────── */
.sdp-flex { display: flex; }
.sdp-grid { display: grid; }
.sdp-flex-col { display: flex; flex-direction: column; }
.sdp-items-center { align-items: center; }
.sdp-justify-center { justify-content: center; }
.sdp-justify-between { justify-content: space-between; }
.sdp-text-center { text-align: center; }
.sdp-text-left { text-align: left; }

.sdp-gap-4 { gap: var(--sdp-space-1); }
.sdp-gap-8 { gap: var(--sdp-space-2); }
.sdp-gap-12 { gap: var(--sdp-space-3); }
.sdp-gap-16 { gap: var(--sdp-space-4); }
.sdp-gap-24 { gap: var(--sdp-space-6); }
.sdp-gap-32 { gap: var(--sdp-space-8); }
.sdp-gap-48 { gap: var(--sdp-space-12); }

.sdp-m-0 { margin: var(--sdp-space-0); }
.sdp-mb-1 { margin-bottom: var(--sdp-space-1); }
.sdp-mb-2 { margin-bottom: var(--sdp-space-2); }
.sdp-mb-3 { margin-bottom: var(--sdp-space-3); }
.sdp-mb-4 { margin-bottom: var(--sdp-space-4); }
.sdp-mb-6 { margin-bottom: var(--sdp-space-6); }
.sdp-mb-8 { margin-bottom: var(--sdp-space-8); }
.sdp-mb-12 { margin-bottom: var(--sdp-space-12); }

.sdp-mt-2 { margin-top: var(--sdp-space-2); }
.sdp-mt-4 { margin-top: var(--sdp-space-4); }
.sdp-mt-6 { margin-top: var(--sdp-space-6); }
.sdp-mt-8 { margin-top: var(--sdp-space-8); }
.sdp-mt-12 { margin-top: var(--sdp-space-12); }

.sdp-p-0 { padding: var(--sdp-space-0); }
.sdp-p-2 { padding: var(--sdp-space-2); }
.sdp-p-4 { padding: var(--sdp-space-4); }
.sdp-p-6 { padding: var(--sdp-space-6); }
.sdp-p-8 { padding: var(--sdp-space-8); }
"""

# Find the utilities block and replace it
# We need to replace everything from /* ── 9. UTILITATS SDP-* ─────────────────────────────────────────── */ to </style>
content = re.sub(r'/\* ── 9\. UTILITATS SDP-\* ─────────────────────────────────────────── \*/.*?</style>', 
                 utils_cleaned + '\n</style>', content, flags=re.DOTALL)

# 4. Remove the inline <style> block from the body, and add .mobile-logo-btn to the head
body_style_block = """<style>
        .mobile-logo-btn { display: none !important; }
        @media (max-width: 1100px) { .mobile-logo-btn { display: flex !important; } }
      
.sdp-flex { display: flex; }
.sdp-grid { display: grid; }
.sdp-flex-col { display: flex; flex-direction: column; }
.sdp-items-center { align-items: center; }
.sdp-justify-center { justify-content: center; }
.sdp-justify-between { justify-content: space-between; }
.sdp-text-center { text-align: center; }
.sdp-text-left { text-align: left; }

.sdp-gap-4 { gap: 4px; }
.sdp-gap-8 { gap: 8px; }
.sdp-gap-12 { gap: 12px; }
.sdp-gap-16 { gap: 16px; }
.sdp-gap-24 { gap: 24px; }
.sdp-gap-32 { gap: 32px; }
.sdp-gap-48 { gap: 48px; }

.sdp-m-0 { margin: 0; }
.sdp-mb-4 { margin-bottom: 4px; }
.sdp-mb-8 { margin-bottom: 8px; }
.sdp-mb-12 { margin-bottom: 12px; }
.sdp-mb-16 { margin-bottom: 16px; }
.sdp-mb-24 { margin-bottom: 24px; }
.sdp-mb-32 { margin-bottom: 32px; }
.sdp-mb-48 { margin-bottom: 48px; }
.sdp-mb-64 { margin-bottom: 64px; }

.sdp-mt-8 { margin-top: 8px; }
.sdp-mt-16 { margin-top: 16px; }
.sdp-mt-24 { margin-top: 24px; }
.sdp-mt-32 { margin-top: 32px; }
.sdp-mt-48 { margin-top: 48px; }

.sdp-p-0 { padding: 0; }
.sdp-p-16 { padding: 16px; }
.sdp-p-24 { padding: 24px; }
.sdp-p-32 { padding: 32px; }

</style>"""
# The user's formatter might have messed up the indentation, so let's use regex to find and remove the style tag in the body
content = re.sub(r'<style>\s*\.mobile-logo-btn \{ display: none !important; \}.*?</style>', '', content, flags=re.DOTALL)

# Add .mobile-logo-btn to the head just before </style>
content = content.replace('</style>', '.mobile-logo-btn { display: none !important; }\n@media (max-width: 1100px) { .mobile-logo-btn { display: flex !important; } }\n</style>', 1)

# 5. Fix the mega-rule and the rest of the targeta mestra css
# Let's replace the whole section 7.21
section_721_regex = r'/\* <pre class="sdp-p-4".*?7\.22 Estadístiques i dashboards \*/'
new_section_721 = """/* ═══════════════════════════════════════════════════════════════════
   7.21 TARGETA MESTRA (Sóc de Poble Card) — RECONSTRUCCIÓ PURA V4.6
   Criteris: CSS Grid per a les barres, Flexbox nadiu, tokens --sdp-*,
   compliment WCAG AAA (48px touch target).
   ═══════════════════════════════════════════════════════════════════ */
.sp-card {
  position: relative;
  background: var(--sdp-superficie);
  border-radius: var(--sdp-radi-m);
  overflow: hidden;
  box-shadow: var(--sdp-ombra-3);
  margin: 0 auto var(--sdp-space-8);
  max-width: 500px;
  transition: box-shadow var(--sdp-t-lenta);
}
.sp-card:hover { box-shadow: var(--sdp-ombra-4); }

.sp-card-link-overlay { position: absolute; inset: 0; z-index: 1; border-radius: inherit; outline: none; }
.sp-card-link-overlay:focus-visible { box-shadow: inset 0 0 0 3px var(--sdp-primary-500); }

/* Capçalera Taronja */
.sp-card-header {
  background: var(--sdp-primary-500);
  padding: var(--sdp-space-3) var(--sdp-space-4);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sdp-space-3);
  position: relative;
  z-index: 2;
}
.sp-card-author-link, .sp-card-author {
  display: flex;
  align-items: center;
  gap: var(--sdp-space-3);
  min-width: 0;
  position: relative;
  z-index: 3;
  color: inherit;
}
.sp-card-avatar {
  width: 42px; height: 42px; flex: none;
  border-radius: 50%; background: var(--sdp-superficie);
  object-fit: cover; box-shadow: var(--sdp-ombra-1);
}
.sp-card-author-info { display: flex; flex-direction: column; min-width: 0; line-height: 1.2; }
.sp-card-author-name { font-weight: 700; color: var(--sdp-pedra-900); font-size: 1.05rem; }
.sp-card-author-location {
  font-size: 0.85rem; color: var(--sdp-pedra-900); opacity: 0.9;
  display: flex; align-items: center; gap: var(--sdp-space-1);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.sp-card-author-location svg { flex: none; width: 14px; height: 14px; }

/* Data / Hora / Botons d'acció de la capçalera */
.sp-card-meta { display: flex; align-items: center; gap: var(--sdp-space-2); flex: none; position: relative; z-index: 3; }
.btn-date-time {
  background: rgba(0, 0, 0, 0.15);
  color: var(--sdp-superficie);
  font-weight: 700;
  border: none;
  min-height: 48px; /* WCAG AAA */
  padding: var(--sdp-space-1) var(--sdp-space-4);
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-radius: var(--sdp-radi-pastilla);
  font-size: 0.75rem;
  line-height: 1.2;
  text-align: center;
  cursor: pointer;
  white-space: nowrap;
  transition: background var(--sdp-t), transform var(--sdp-t);
  position: relative;
  z-index: 3;
}
.btn-date-time:hover { background: rgba(0, 0, 0, 0.25); transform: scale(1.03); }
.btn-date-time strong { font-size: 0.9rem; font-weight: 800; }

.btn-icon-orange {
  background: rgba(0, 0, 0, 0.15);
  color: var(--sdp-superficie);
  border: none;
  width: 48px; height: 48px; /* WCAG AAA */
  flex: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background var(--sdp-t), transform var(--sdp-t);
  position: relative;
  z-index: 3;
}
.btn-icon-orange:hover { background: rgba(0, 0, 0, 0.25); transform: scale(1.08); }
.btn-icon-orange svg { width: 20px; height: 20px; }

/* Media */
.sp-card-media { width: 100%; position: relative; background: var(--sdp-pedra-100); aspect-ratio: 1 / 1; }
.sp-card-media img { width: 100%; height: 100%; display: block; object-fit: cover; }
.sp-card-play { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: var(--sdp-superficie); z-index: 2; pointer-events: none; }
.sp-card-play svg { width: 64px; height: 64px; fill: currentColor; opacity: 0.92; }

/* Cos */
.sp-card-body { padding: var(--sdp-space-6) var(--sdp-space-6) var(--sdp-space-4); text-align: left; position: relative; z-index: 2; }
.sp-card-body:has(.sp-card-title:only-child) { text-align: center; }
.sp-card-title-row { display: flex; align-items: baseline; justify-content: space-between; gap: var(--sdp-space-3); margin-bottom: var(--sdp-space-2); flex-wrap: wrap; }
.sp-card-title { font-size: 1.4rem; font-weight: 800; color: var(--sdp-pedra-900); margin: 0; flex: 1; line-height: var(--sdp-leading-snug); }
.sp-card-title:only-child { text-align: center; flex: none; width: 100%; }
.sp-card-subtitle { color: var(--sdp-secondary-600); font-weight: 700; font-size: 1rem; margin-bottom: var(--sdp-space-3); }
.sp-card-text { color: var(--sdp-pedra-700); font-size: 0.95rem; line-height: var(--sdp-leading-body); margin-bottom: var(--sdp-space-6); }
.sp-card-price { font-size: 1.2rem; font-weight: 800; color: var(--sdp-secondary-500); background: var(--sdp-secondary-50); padding: var(--sdp-space-1) var(--sdp-space-3); border-radius: var(--sdp-radi-pastilla); white-space: nowrap; flex: none; }

/* Etiquetes Gestoria */
.sp-card-labels { display: flex; flex-wrap: wrap; justify-content: center; gap: var(--sdp-space-2); margin-top: var(--sdp-space-4); margin-bottom: var(--sdp-space-2); position: relative; z-index: 2; }
.sp-card-label { padding: var(--sdp-space-1) var(--sdp-space-3); border-radius: var(--sdp-radi-pastilla); font-size: 0.7rem; font-weight: 800; letter-spacing: 0.05em; }

.sp-card-copyright { color: var(--sdp-pedra-400); font-size: 0.65rem; letter-spacing: 0.05em; margin-top: var(--sdp-space-4); }

/* ── LAYOUT GRID: PEU I BARRA BLAVA ── */
.sp-card-footer, header.bar-blue {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: center;
  gap: var(--sdp-space-3);
  position: relative;
}

/* Backgrounds and paddings */
.sp-card-footer {
  background: var(--sdp-secondary-500);
  color: var(--sdp-superficie);
  padding: var(--sdp-space-3) var(--sdp-space-4);
  min-height: 60px;
}
header.bar-blue {
  height: var(--sdp-alt-accio);
  background: var(--sdp-secondary-500);
  color: var(--sdp-superficie);
  padding: 0 var(--sdp-space-6);
}

/* Esquerra, Centre, Dreta per al Grid */
.bar-blue-left {
  display: flex;
  align-items: center;
  gap: var(--sdp-space-4);
  justify-self: start;
}

.sp-card-actions {
  display: flex;
  align-items: center;
  gap: var(--sdp-space-6);
  justify-self: center;
}

.sp-card-connect {
  background: var(--sdp-secondary-700);
  border: none;
  color: var(--sdp-superficie);
  font-weight: 800;
  font-size: 0.85rem;
  letter-spacing: 0.02em;
  cursor: pointer;
  min-height: 48px; /* WCAG AAA */
  padding: 0 var(--sdp-space-5);
  border-radius: var(--sdp-radi-pastilla);
  white-space: nowrap;
  display: flex;
  align-items: center;
  justify-content: center;
  justify-self: end;
  transition: background var(--sdp-t), transform var(--sdp-t), opacity var(--sdp-t);
  position: relative;
  z-index: 3;
}
.sp-card-connect:hover { background: var(--sdp-secondary-800); transform: scale(1.03); }
.sp-card-connect:active { transform: scale(0.98); }

/* Botons d'acció */
.sp-card-action {
  background: transparent;
  border: none;
  color: var(--sdp-superficie);
  width: 48px; height: 48px; /* WCAG AAA */
  min-width: 48px; min-height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  opacity: 0.9;
  border-radius: var(--sdp-radi-s);
  transition: opacity var(--sdp-t), transform var(--sdp-t), background var(--sdp-t);
  position: relative;
  z-index: 3;
}
.sp-card-action .icon { width: 26px; height: 26px; stroke-width: 2.3; flex: none; }
.sp-card-action:hover { opacity: 1; transform: translateY(-1px); background: rgba(255, 255, 255, 0.08); }

/* ── BARRA TARONJA GLOBAL ── */
section.bar-orange {
  height: var(--sdp-alt-accio);
  background: var(--sdp-primary-500);
  color: var(--sdp-pedra-900);
  padding: 0 var(--sdp-space-6);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--sdp-space-3);
}
.bar-orange .context-left { display: flex; align-items: center; gap: var(--sdp-space-3); min-width: 0; flex: 1; }
.bar-orange .sp-card-author-info { line-height: 1.25; }
.bar-orange .sp-card-author-name { font-size: 0.95rem; font-weight: 700; }
.bar-orange .sp-card-author-location { font-size: 0.8rem; opacity: 0.85; }
.bar-orange .bar-actions { display: flex; align-items: center; gap: var(--sdp-space-2); flex: none; }

/* Tooltip (bocata) */
.tooltip-container { position: relative; display: inline-flex; z-index: 4; }
.tooltip-text {
  visibility: hidden; opacity: 0;
  background: var(--sdp-pedra-900); color: var(--sdp-superficie);
  text-align: center; border-radius: 4px; padding: 6px 10px;
  position: absolute; z-index: 10; top: 100%; left: 50%;
  transform: translateX(-50%) translateY(8px);
  font-size: 0.75rem; font-weight: 700; white-space: nowrap;
  transition: opacity var(--sdp-t), visibility var(--sdp-t), transform var(--sdp-t);
  pointer-events: none; margin-top: 6px;
}
.tooltip-container:hover .tooltip-text, .tooltip-container:focus-within .tooltip-text {
  visibility: visible; opacity: 1; transform: translateX(-50%) translateY(0);
}
.tooltip-text::after {
  content: ""; position: absolute; bottom: 100%; left: 50%;
  margin-left: -5px; border: 5px solid transparent; border-bottom-color: var(--sdp-pedra-900);
}

/* ═══════════════════════════════════════════════════════════════════
   RESPONSIVE UNIFICAT — Targetes Mestres + Barres
   ═══════════════════════════════════════════════════════════════════ */
@media (max-width: 720px) {
  .sp-card { max-width: 100%; }
  .sp-card-body { padding: var(--sdp-space-5) var(--sdp-space-4) var(--sdp-space-3); }
  .sp-card-actions { gap: var(--sdp-space-4); }
  .sp-card-connect { padding: 0 var(--sdp-space-4); font-size: 0.8rem; min-height: 48px; }
  .sp-card-footer { padding: var(--sdp-space-2) var(--sdp-space-3); }
  .bar-blue .sp-card-connect { padding: 0 var(--sdp-space-4); }
}

@media (max-width: 480px) {
  /* WCAG RESPECTAT: mai baixem de 48px efectius interactius */
  .sp-card-header { padding: var(--sdp-space-2) var(--sdp-space-3); gap: var(--sdp-space-2); }
  .sp-card-avatar { width: 36px; height: 36px; }
  .sp-card-author-name { font-size: 0.95rem; }
  .sp-card-author-location { font-size: 0.75rem; }
  
  .sp-card-actions { gap: var(--sdp-space-3); }
  .sp-card-action .icon { width: 22px; height: 22px; stroke-width: 2.2; }
  .sp-card-connect {
    padding: 0 var(--sdp-space-3);
    font-size: 0.75rem;
  }
  .sp-card-footer { padding: var(--sdp-space-2); gap: var(--sdp-space-2); }
  
  header.bar-blue, section.bar-orange { padding: 0 var(--sdp-space-3); }
  .bar-blue-left { gap: var(--sdp-space-2); }
}

/* 7.22 Estadístiques i dashboards */"""
content = re.sub(section_721_regex, new_section_721, content, flags=re.DOTALL)

# 6. Duplicated variables in :root
# Look for --sdp-info: #1E40AF; inside the first :root
content = re.sub(r'--sdp-info: #1E40AF;\s*', '', content, count=1)
# --sdp-pedra-900 duplicated in dark mode
content = re.sub(r'--sdp-pedra-900: #ffffff;\s*--sdp-pedra-900: #ffffff;', '--sdp-pedra-900: #ffffff;', content)
content = re.sub(r'--sdp-pedra-900: #111111;\s*--sdp-pedra-900: #111111;', '--sdp-pedra-900: #111111;', content)

# 7. Add pre code tags to section 34 Variables CSS
section_34_regex = r'<div class="sdp-p-4">\s*CONVENCIÓ DE NOMENCLATURA SDP.*?</div>'
match = re.search(section_34_regex, content, flags=re.DOTALL)
if match:
    old_content = match.group(0)
    new_content_34 = old_content.replace('<div class="sdp-p-4">', '<div class="sdp-p-4"><pre style="white-space: pre-wrap; font-family: monospace;"><code>')
    new_content_34 = new_content_34.replace('</div>', '</code></pre></div>')
    content = content.replace(old_content, new_content_34)

# 8. Check for any remaining duplicated `.bar-blue` in `.bar-blue .bar-blue` just in case
content = content.replace('.bar-blue .bar-blue', '.bar-blue')

with open('/Users/javillinares/Documents/Antigravity/Som de Poble/socdepoble.org/disseny_pedra_seca.html', 'w', encoding='utf-8') as f:
    f.write(content)
print("Fixes applied successfully!")
