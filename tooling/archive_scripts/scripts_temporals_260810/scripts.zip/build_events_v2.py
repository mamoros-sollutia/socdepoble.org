import re

# Read disseny.html to extract the cards
with open("src/html/disseny.html", "r", encoding="utf-8") as f:
    disseny = f.read()

# 1. Festa Major del Poble
# Search for <article class="sp-card sp-card--calendari"> ... </article>
festa_match = re.search(r'<article class="sp-card sp-card--calendari">.*?Festa Major del Poble.*?</article>', disseny, re.DOTALL)
festa_card = festa_match.group(0) if festa_match else "<!-- CARD 1 MISSING -->"

# 2. On fem la paella popular
paella_match = re.search(r'<article class="sp-card">.*?On fem la paella popular\?.*?</article>', disseny, re.DOTALL)
paella_card = paella_match.group(0) if paella_match else "<!-- CARD 2 MISSING -->"

# 3. Necessite transport a Alcoi
transport_match = re.search(r'<article class="sp-card">.*?Necessite transport a Alcoi.*?</article>', disseny, re.DOTALL)
transport_card = transport_match.group(0) if transport_match else "<!-- CARD 3 MISSING -->"

# Need to add calendar badge to transport card
if transport_card != "<!-- CARD 3 MISSING -->":
    # Insert badge before <h1>
    badge_html = """<div class="sp-card-calendar-badge">
    <div class="sp-card-calendar-badge__dia">11</div>
    <div class="sp-card-calendar-badge__mes">AGOST</div>
</div>
"""
    transport_card = transport_card.replace("<h1>Necessite transport a Alcoi</h1>", badge_html + "<h1>Necessite transport a Alcoi</h1>")


# Now read pobles.html to use its skeleton
with open("src/html/pobles.html", "r", encoding="utf-8") as f:
    pobles = f.read()

# Replace <title>
pobles = pobles.replace("<title>Pobles | Sóc de Poble</title>", "<title>Events | Sóc de Poble</title>")

# In pobles.html, the header.page-title contains the H1.
# We need to replace "Pobles" inside that header with "Events".
# <span class="sp-card-label label-orange">POBLES</span> -> <span class="sp-card-label label-orange">EVENTS</span>
# <h1>Pobles</h1> -> <h1>Events</h1>
header_match = re.search(r'(<header class="page-title[^>]*>.*?)(<h1>Pobles</h1>)(.*?<span class="sp-card-label label-orange">)(POBLES)(</span>.*?</header>)', pobles, re.DOTALL)
if header_match:
    new_header = header_match.group(1) + "<h1>Events</h1>" + header_match.group(3) + "EVENTS" + header_match.group(5)
    pobles = pobles[:header_match.start()] + new_header + pobles[header_match.end():]

# Now, everything after </header> up to <div class="sdp-card-grid"> needs to be replaced.
# Actually, the user says "después del H1 y de su decoración correspondiente... metes el calendario".
# So after </header> (the .page-title), we put the calendar, then the H2, then the grid.

# Let's read the calendar from events.html (the one we built earlier)
with open("src/html/events.html", "r", encoding="utf-8") as f:
    old_events = f.read()

cal_start = old_events.find('<!-- CALENDARI TOOLBAR -->')
cal_end = old_events.find('<!-- ANCORES DE MEMÒRIA RECENT -->')
calendar_html = old_events[cal_start:cal_end] if cal_start != -1 else "<!-- CALENDAR MISSING -->"

# Let's find where </header> of page-title ends in pobles
page_title_end = pobles.find('</header>', pobles.find('<header class="page-title')) + len('</header>')
pobles_post_header = pobles[page_title_end:]

# Replace the H2 and grid with our new one
h2_html = """
<div class="sdp-text-center sdp-my-8">
    <h2>Esdeveniments</h2>
    <p class="lead">Cerca esdeveniments prop de les teues comarques.</p>
</div>
<div class="sdp-card-grid">
"""
grid_content = festa_card + "\n" + paella_card + "\n" + transport_card + "\n</div>"

# Find the start of H2 in pobles
h2_start = pobles_post_header.find('<div class="sdp-text-center')
if h2_start == -1: h2_start = pobles_post_header.find('<h2>')

# Find the end of grid in pobles
grid_start = pobles_post_header.find('<div class="sdp-card-grid">')
grid_end = pobles_post_header.find('</div>', grid_start)
# Wait, </main> is at the end. It's safer to just slice out everything before </main>
# and reconstruct the main content.
main_end = pobles_post_header.find('</main>')
footer = pobles_post_header[main_end:]

new_main_content = calendar_html + h2_html + grid_content + "\n"

final_html = pobles[:page_title_end] + "\n<div class=\"sdp-p-4 sdp-p-md-8\">\n" + new_main_content + "</div>\n" + footer

with open("src/html/events.html", "w", encoding="utf-8") as f:
    f.write(final_html)

print("Re-built events.html with proper layout.")
