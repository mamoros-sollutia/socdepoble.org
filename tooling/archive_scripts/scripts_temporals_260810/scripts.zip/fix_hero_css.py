import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Make sure the container has overflow: hidden and no height: auto overriding aspect ratio.
html = html.replace('style="height: auto; aspect-ratio: 6/1;"', 'style="aspect-ratio: 6/1; overflow: hidden; display: flex; align-items: center; justify-content: center;"')

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Updated hero image CSS for extreme ratio")
