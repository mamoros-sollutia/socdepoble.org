import os
import glob

# Add "Mapa" menu item in all HTML files
html_dir = "src/html"
html_files = glob.glob(os.path.join(html_dir, "*.html"))

for file_path in html_files:
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # We want to insert: <a class="nav-item" href="mapa.html">Mapa</a>
    # after <a class="nav-item" href="events.html">Events</a>
    
    if '<a class="nav-item" href="mapa.html">Mapa</a>' not in content:
        target = '<a class="nav-item" href="events.html">Events</a>'
        replacement = target + '\n<a class="nav-item" href="mapa.html">Mapa</a>'
        new_content = content.replace(target, replacement)
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(new_content)

print("Menu Mapa added successfully to all HTML files.")
