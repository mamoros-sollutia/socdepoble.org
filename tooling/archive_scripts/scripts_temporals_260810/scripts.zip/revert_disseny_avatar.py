import re

html_path = "src/html/disseny.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Revert all town landscapes back to Sóc de Poble logo
html = html.replace(
    'src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"',
    'src="https://socdepoble.org/assets/system/ui/logo-socdepoble-cuadrat-verd.svg"'
)

# But wait, the Targeta Mestra: Pobles should still have the town landscape as its avatar.
# Let's find that section and put it back.
section_idx = html.find('<h4>20.5 Targeta Mestra: Pobles</h4>')
if section_idx != -1:
    end_idx = html.find('</article>', section_idx)
    sub = html[section_idx:end_idx]
    
    # In this section, there are two images: the avatar and the hero.
    # The hero should be P_20161028_153325_SRES.jpg (the snail).
    # The avatar should be the blue landscape.
    # Currently both might be logo-socdepoble-cuadrat-verd.svg? 
    # Wait! If I just reverted everything, then the hero image in 20.5 was NOT reverted, it was already P_20161028.
    # But the avatar in 20.5 is now the green logo. Let's fix that specific avatar:
    sub = sub.replace(
        '<img alt="Gent de la Torre" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/system/ui/logo-socdepoble-cuadrat-verd.svg"/>',
        '<img alt="Gent de la Torre" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"/>'
    )
    html = html[:section_idx] + sub + html[end_idx:]

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Reverted disseny.html avatars")
