import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Current block:
# <div class="sdp-text-center sdp-mb-6">
#   <h2>La Torre de les Maçanes</h2>
#   <p class="lead">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l'Alacantí, a la comarca històrica de la Foia de Xixona.</p>
# </div>

new_block = """<div class="sdp-text-center sdp-mb-6">
  <h2 style="color: var(--sdp-secondary-600); margin-top: var(--sdp-space-2);">L'Alacantí</h2>
  <h3 class="sdp-mt-6" style="margin-bottom: var(--sdp-space-2);">La Torre de les Maçanes</h3>
  <p style="max-width: 600px; margin: 0 auto; color: var(--sdp-pedra-600);">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l'Alacantí, a la comarca històrica de la Foia de Xixona.</p>
</div>"""

pattern = re.compile(r'<div class="sdp-text-center sdp-mb-6">\s*<h2>La Torre de les Maçanes</h2>\s*<p class="lead">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l\'Alacantí, a la comarca històrica de la Foia de Xixona.</p>\s*</div>')

if pattern.search(html):
    html = pattern.sub(new_block, html)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Updated headers in gentdelatorre.html")
else:
    print("Pattern not found. Checking current content of gentdelatorre.html")

