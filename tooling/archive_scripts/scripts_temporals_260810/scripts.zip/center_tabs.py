import re

css_path = "src/css/pedra-seca.css"
with open(css_path, "r", encoding="utf-8") as f:
    css = f.read()

# Replace the .tabs definition to include justify-content: center
old_tabs = ".tabs { display: flex; border-bottom: 1px solid var(--sdp-vora); margin-bottom: var(--sdp-space-4); }"
new_tabs = ".tabs { display: flex; justify-content: center; border-bottom: 1px solid var(--sdp-vora); margin-bottom: var(--sdp-space-4); }"

if old_tabs in css:
    css = css.replace(old_tabs, new_tabs)
    with open(css_path, "w", encoding="utf-8") as f:
        f.write(css)
    print("Centered .tabs in pedra-seca.css")
else:
    print("Could not find the exact .tabs definition.")

