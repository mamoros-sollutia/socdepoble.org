import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace aspect ratio
html = html.replace('aspect-ratio: 21/9;', 'aspect-ratio: 3/1;')
html = html.replace('object-fit: cover;"', 'object-fit: cover; object-position: center;"')

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Updated hero image aspect ratio to 3/1")
