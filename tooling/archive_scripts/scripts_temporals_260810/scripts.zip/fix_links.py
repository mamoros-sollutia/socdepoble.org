import re

def fix_links_in_file(filepath, is_pobles=False):
    with open(filepath, "r", encoding="utf-8") as f:
        html = f.read()
        
    if is_pobles:
        # Replace all card overlays
        html = html.replace('<a class="sp-card-link-overlay" href="#" title="Obrir Disseny"></a>', '<a class="sp-card-link-overlay" href="gentdelatorre.html" title="Obrir poble"></a>')
        # Replace all author links
        html = html.replace('<a class="sp-card-author-link" href="javillinares.html" title="Anar al perfil de l\'autor">', '<a class="sp-card-author-link" href="gentdelatorre.html" title="Anar al perfil del poble">')
    else:
        # In disseny.html, only fix the ones inside Targeta Mestra: Pobles section
        # Find section
        section_idx = html.find('<h4>20.5 Targeta Mestra: Pobles</h4>')
        if section_idx != -1:
            end_idx = html.find('</article>', section_idx)
            sub = html[section_idx:end_idx]
            sub = sub.replace('<a class="sp-card-link-overlay" href="#" title="Obrir Disseny"></a>', '<a class="sp-card-link-overlay" href="gentdelatorre.html" title="Obrir poble"></a>')
            sub = sub.replace('<a class="sp-card-author-link" href="javillinares.html" title="Anar al perfil de l\'autor">', '<a class="sp-card-author-link" href="gentdelatorre.html" title="Anar al perfil del poble">')
            html = html[:section_idx] + sub + html[end_idx:]

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Fixed links in {filepath}")

fix_links_in_file("src/html/pobles.html", is_pobles=True)
fix_links_in_file("src/html/disseny.html", is_pobles=False)

