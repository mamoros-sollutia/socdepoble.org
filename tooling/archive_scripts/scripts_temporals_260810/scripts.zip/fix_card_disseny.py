import re

disseny_path = "src/html/disseny.html"

with open(disseny_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace the text styling
html = html.replace('<p class="sdp-mb-4 sdp-text-center">Aquesta variant de la Targeta Mestra s\'utilitza per a representar nuclis poblacionals.', '<p>Aquesta variant de la Targeta Mestra s\'utilitza per a representar nuclis poblacionals.')

# Remove the grid div
start_text = '<h4>20.5 Targeta Mestra: Pobles</h4>\n<p>Aquesta variant de la Targeta Mestra s\'utilitza per a representar nuclis poblacionals. Utilitza la mateixa estructura base, però adapta el bloc d\'autor per a representar la identitat col·lectiva: el nom de l\'autor mostra "Gent de [Poble]" i la ubicació mostra la comarca corresponent.</p>\n<div class="sdp-card-grid sdp-mb-8">\n'

if start_text in html:
    html = html.replace(start_text, '<h4>20.5 Targeta Mestra: Pobles</h4>\n<p>Aquesta variant de la Targeta Mestra s\'utilitza per a representar nuclis poblacionals. Utilitza la mateixa estructura base, però adapta el bloc d\'autor per a representar la identitat col·lectiva: el nom de l\'autor mostra "Gent de [Poble]" i la ubicació mostra la comarca corresponent.</p>\n')
    
    # We also need to remove the closing </div> that comes right after the </article> for this specific section
    # Let's find the article end after 20.5
    section_index = html.find('<h4>20.5 Targeta Mestra: Pobles</h4>')
    article_end = html.find('</article>', section_index)
    if article_end != -1:
        div_end = html.find('</div>', article_end)
        # Assuming the </div> is immediately after </article>\n
        # let's replace </article>\n</div>\n with </article>\n
        # or we can do it more safely:
        sub = html[article_end:article_end+50]
        html = html[:article_end] + sub.replace('</article>\n</div>', '</article>') + html[article_end+len(sub):]
        
    with open(disseny_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Fixed.")
else:
    print("Could not find the exact start text to remove grid.")
    
    # Let's try regex if exact match failed
    pattern = re.compile(r'(<h4>20\.5 Targeta Mestra: Pobles</h4>\n<p[^>]*>.*?<\/p>)\n<div class="sdp-card-grid sdp-mb-8">\n(.*?<\/article>)\n<\/div>', re.DOTALL)
    if pattern.search(html):
        html = pattern.sub(r'\1\n\2', html)
        with open(disseny_path, "w", encoding="utf-8") as f:
            f.write(html)
        print("Fixed via regex.")

