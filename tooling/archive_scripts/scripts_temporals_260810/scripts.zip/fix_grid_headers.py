import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Fix Quadre de Comandament inline styles
html = html.replace(
    '<h3 class="sdp-mb-4" style="color: var(--sdp-primary-500);">Quadre de Comandament</h3>',
    '<h3 class="sdp-mb-4">Quadre de Comandament</h3>'
)
html = html.replace(
    '<h4 class="sdp-mb-4" style="color: var(--sdp-secondary-500);">Resum d\'Activitat</h4>',
    '<h4 class="sdp-mb-4">Resum d\'Activitat</h4>'
)
html = html.replace(
    '<h4 class="sdp-mb-4 sdp-mt-8" style="color: var(--sdp-secondary-500);">El Meu Arxiu</h4>',
    '<h4 class="sdp-mb-4 sdp-mt-8">El Meu Arxiu</h4>'
)

# Replace the H3 for Publicacions with a centered H2 + entradilla
publicacions_old = '<h3 class="sdp-mb-4" style="color: var(--sdp-primary-500);">Publicacions de La Torre de les Maçanes</h3>'
publicacions_new = '''<div class="sdp-text-center sdp-mb-6 sdp-mt-8">
  <h2>Publicacions de La Torre de les Maçanes</h2>
  <p class="lead">Tot el pols informatiu del nostre poble en temps real, generat pel veïnat i entitats locals.</p>
</div>'''

if publicacions_old in html:
    html = html.replace(publicacions_old, publicacions_new)
else:
    print("Could not find the exact Publicacions H3 string.")

# Fix the grid class from sp-card-grid to sdp-card-grid
html = html.replace('class="sp-card-grid"', 'class="sdp-card-grid"')

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Applied fixes for headers and grid class.")
