import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Extract the block
block_match = re.search(r'<div class="sdp-text-center sdp-mb-6">\s*<h2>.*?</h2>\s*<p class="lead">.*?</p>\s*</div>\s*', html)
if block_match:
    block_str = block_match.group(0)
    # Remove from old position
    html = html.replace(block_str, '')
    
    # Insert just inside <article class="content-wrapper">
    insert_point = html.find('<article class="content-wrapper">')
    if insert_point != -1:
        insert_point += len('<article class="content-wrapper">\n')
        html = html[:insert_point] + "  " + block_str + html[insert_point:]
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        print("Moved entradilla inside content-wrapper.")
    else:
        print("Could not find content-wrapper")
else:
    print("Could not find the block")

