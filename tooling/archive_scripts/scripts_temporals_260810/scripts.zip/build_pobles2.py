import re

html_path = "src/html/pobles.html"
mur_path = "src/html/mur.html"

with open(mur_path, "r", encoding="utf-8") as f:
    html = f.read()

# Update meta tags and title
html = re.sub(r'<title>.*?</title>', '<title>Pobles | Sóc de Poble</title>', html)
html = html.replace('<h1>Mur de Sóc de Poble</h1>', '<h1>Pobles</h1>')
html = html.replace('<span class="sp-card-label label-orange">MUR</span>', '<span class="sp-card-label label-orange">POBLES</span>')
html = html.replace('<h2>El pols del nostre poble en temps real</h2>', '<h2>Nodes i territori</h2>')
html = html.replace('<p class="lead">Descobreix tot el que passa a La Torre de les Maçanes. Anuncis, esdeveniments, memòria i molt més.</p>', '<p class="lead">Cerca pobles, gent i territoris de la nostra geografia.</p>')

# We will take the exact first card from mur.html and modify it
card_start = html.find('<article class="sp-card">')
card_end = html.find('</article>', card_start) + len('</article>')

card_html = html[card_start:card_end]

# Modify the card content
# 1. Author Name
card_html = card_html.replace('Javi Llinares', 'Gent de la Torre')
# 2. Author Location (Comarca)
card_html = card_html.replace('<div class="sp-card-author-location">La Torre de les Maçanes</div>', '<div class="sp-card-author-location">L\'Alacantí</div>')
# 3. Avatar: Use the town logo for now, or just the default one. The user said "en vez de poner el nombre del usuario pondrás Gent de la Torre". I'll keep the avatar img tag but maybe change src to the logo or just keep the javi avatar for a second? No, let's change it to the town logo.
card_html = re.sub(r'<img alt="Gent de la Torre" class="sp-card-avatar[^>]+>', '<img alt="Gent de la Torre" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/system/ui/logo-socdepoble-cuadrat-verd.svg"/>', card_html)
card_html = card_html.replace('<img alt="Javi Llinares" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/uploads/gent/javi-llinares/avatars/javi-llinares-perfil-1200px.jpg" style="border-radius: 50%; object-fit: cover;"/>', '<img alt="Avatar" class="sp-card-avatar sdp-p-0" src="https://socdepoble.org/assets/system/ui/logo-socdepoble-cuadrat-verd.svg"/>')

# 4. Media image
card_html = re.sub(r'<img alt="Disseny Pedra Seca" src="\.\./assets/img/ibanez_pedra_seca_design_1780873465211\.png"/>', '<img alt="La Torre de les Maçanes" src="../assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"/>', card_html)

# 5. Body Title and Subtitle
card_html = card_html.replace('<h1>Disseny Pedra Seca</h1>', '<h1>La Torre de les Maçanes</h1>')
card_html = card_html.replace('<h2>Sistema oficial de disseny per a Sóc de Poble</h2>', '<h2>L\'Alacantí</h2>')
card_html = card_html.replace('<p class="sp-card-text">Inclou la Targeta Mestra, els colors oficials, i tots els elements preparats, inclús els skills i scripts, per a que qualsevol IA puga entendre este sistema i reproduir-lo.</p>', '<p class="sp-card-text">La Torre de les Maçanes és una vila i municipi del País Valencià situat a la comarca de l\'Alacantí, a la comarca històrica de la Foia de Xixona.</p>')

# 6. Labels
card_html = card_html.replace('<span class="sp-card-label label-orange">MUR</span>', '<span class="sp-card-label label-orange">POBLES</span>')
card_html = card_html.replace('<span class="sp-card-label label-blue">Disseny UI</span>', '<span class="sp-card-label label-blue">L\'Alacantí</span>')

# Find grid start
grid_start = html.find('<div class="sdp-card-grid sdp-mb-8">')
grid_end = html.find('</div>\n    </article>', grid_start)

if grid_start != -1 and grid_end != -1:
    before = html[:grid_start + len('<div class="sdp-card-grid sdp-mb-8">\n')]
    after = html[grid_end:]
    
    new_html = before + (card_html * 6) + after
    
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(new_html)
    print("pobles.html rebuilt successfully.")
else:
    print("Could not find grid boundaries.")
