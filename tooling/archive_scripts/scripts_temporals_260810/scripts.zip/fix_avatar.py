import re

html_path = "src/html/gentdelatorre.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

# Fix alt text for the hero image
html = html.replace('alt="Javi Llinares"', 'alt="Gent de La Torre"')

# Fix the avatar source in the orange bar
avatar_src_wrong = 'https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/P_20161028_153325_SRES.jpg" style="border-radius: 50%; object-fit: cover;"'
avatar_src_right = 'https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/gentdelatorre-logo-bn-q.png" style="border-radius: 50%; object-fit: cover; background: white;"'

html = html.replace(avatar_src_wrong, avatar_src_right)

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print("Avatar fixed")
