import re

def fix_gentdelatorre():
    html_path = "src/html/gentdelatorre.html"
    with open(html_path, "r", encoding="utf-8") as f:
        html = f.read()

    # 1. Fix the avatar from the logo back to the blueish landscape
    html = html.replace(
        'src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/gentdelatorre-logo-bn-q.png"',
        'src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"'
    )

    # 2. Fix the author location from @gentdelatorre to L'Alacantí
    html = html.replace(
        '<div class="sp-card-author-location">@gentdelatorre</div>',
        '<div class="sp-card-author-location">L\'Alacantí</div>'
    )

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Fixed gentdelatorre.html")

def fix_cards(html_path):
    with open(html_path, "r", encoding="utf-8") as f:
        html = f.read()

    # In cards, the current avatar is logo-socdepoble-cuadrat-verd.svg
    # We change it to the blueish landscape
    html = html.replace(
        'src="https://socdepoble.org/assets/system/ui/logo-socdepoble-cuadrat-verd.svg"',
        'src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"'
    )

    # The current media image in pobles.html cards is toponim-la-torre-de-les-macanes-2048px.jpg
    # But it shouldn't be the avatar! Wait, the media image is currently the blueish one.
    # The user said: "Y la foto de portada cámbiala y ponla como avatar. Y la que has metido como portada, ponla como foto de portada en card y en página"
    # Wait, the blueish photo (toponim) was the media image in pobles.html.
    # So we change the media image from toponim... to P_20161028_153325_SRES.jpg (the snail).
    
    # Let's target the exact img tag for the card media:
    # <img alt="La Torre de les Maçanes" src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"/>
    html = html.replace(
        '<img alt="La Torre de les Maçanes" src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/toponim-la-torre-de-les-macanes-2048px.jpg"/>',
        '<img alt="La Torre de les Maçanes" src="https://socdepoble.org/assets/uploads/poble/la-torre-de-les-macanes/P_20161028_153325_SRES.jpg"/>'
    )

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Fixed cards in {html_path}")

fix_gentdelatorre()
fix_cards("src/html/pobles.html")
fix_cards("src/html/disseny.html")

