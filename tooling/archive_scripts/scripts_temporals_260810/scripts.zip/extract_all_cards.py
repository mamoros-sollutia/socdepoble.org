import re

# 1. Get cards from disseny.html
html_path = "src/html/disseny.html"
with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

cards = []
search_start = html.find('<h4>20.1 Targeta Mestra: Mur</h4>')

while True:
    card_start = html.find('<article class="sp-card', search_start)
    if card_start == -1:
        break
        
    depth = 0
    i = card_start
    card_end = -1
    while i < len(html):
        if html[i:].startswith('<article'):
            depth += 1
            i += 8
        elif html[i:].startswith('</article>'):
            depth -= 1
            i += 10
            if depth == 0:
                card_end = i
                break
        else:
            i += 1
            
    if card_end != -1:
        # Check if the section is one of the Targeta Mestras (between 20.1 and 20.10)
        # To avoid grabbing cards from other sections if search_start moved past 20.10.
        cards.append(html[card_start:card_end])
        search_start = card_end
    else:
        break

# We only want the first 10 cards (from 20.1 to 20.10)
cards = cards[:10]
print(f"Found {len(cards)} cards.")

# 2. Inject into gentdelatorre.html
gent_path = "src/html/gentdelatorre.html"
with open(gent_path, "r", encoding="utf-8") as f:
    gent_html = f.read()

# Instead of searching for the exact grid, we'll find where to put it.
# We'll put it right after the dashboard/arxiu section inside the General tab.
# Let's find </main>.
main_end = gent_html.rfind('</main>')

# But wait, there might be an old grid. Let's remove it if it exists.
grid_start = gent_html.find('<div class="sp-card-grid">')
if grid_start != -1:
    depth = 0
    i = grid_start
    grid_end = -1
    while i < len(gent_html):
        if gent_html[i:].startswith('<div'):
            depth += 1
            i += 4
        elif gent_html[i:].startswith('</div>'):
            depth -= 1
            i += 6
            if depth == 0:
                grid_end = i
                break
        else:
            i += 1
    # Replace the existing grid
    new_grid_content = '\n'.join(cards)
    new_grid = f'<div class="sp-card-grid">\n{new_grid_content}\n</div>'
    gent_html = gent_html[:grid_start] + new_grid + gent_html[grid_end:]
else:
    # No grid exists, insert it before </main>
    new_grid_content = '\n'.join(cards)
    new_grid = f"""
    <div style="margin-top: 2rem;">
      <h3 class="sdp-mb-4" style="color: var(--sdp-primary-500);">Publicacions de La Torre de les Maçanes</h3>
      <div class="sp-card-grid">
{new_grid_content}
      </div>
    </div>
"""
    gent_html = gent_html[:main_end] + new_grid + gent_html[main_end:]

with open(gent_path, "w", encoding="utf-8") as f:
    f.write(gent_html)
print("Updated gentdelatorre.html")

