import os
import glob
import re

html_dir = "src/html"
html_files = glob.glob(os.path.join(html_dir, "*.html"))

# We want to replace the User Avatar block in all files with the correct Javi Llinares avatar.
# The correct block we want:
correct_avatar = """<!-- 5. User Avatar -->
<div class="icon" onclick="document.getElementById('profileSidebar').classList.add('open'); document.getElementById('profileSidebarOverlay').classList.add('open');" style="cursor: pointer;" title="Obrir menú de perfil">
  <img alt="Javi Llinares" src="https://socdepoble.org/assets/uploads/gent/javi-llinares/avatars/javi-llinares-perfil-1200px.jpg"/>
</div>"""

for file_path in html_files:
    with open(file_path, "r", encoding="utf-8") as f:
        html = f.read()

    # Find the block starting with <!-- 5. User Avatar --> and ending with </div> (the first one)
    # Actually, it's safer to use regex.
    pattern = re.compile(r'<!-- 5\. User Avatar -->\s*<div class="icon"[^>]*>.*?</div>', re.DOTALL)
    
    new_html, num_subs = pattern.subn(correct_avatar, html)
    
    if num_subs > 0 and new_html != html:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(new_html)
        print(f"Updated User Avatar in {os.path.basename(file_path)}")

