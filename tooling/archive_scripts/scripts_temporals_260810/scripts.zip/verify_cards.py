import hashlib
from bs4 import BeautifulSoup

def get_card_hash(soup, title_text):
    for article in soup.find_all('article', class_='sp-card'):
        h1 = article.find('h1')
        if h1 and title_text in h1.text:
            return hashlib.md5(str(article).encode('utf-8')).hexdigest()
    return None

with open("src/html/events.html", "r") as f:
    events = BeautifulSoup(f, 'html.parser')
with open("src/html/disseny.html", "r") as f:
    disseny = BeautifulSoup(f, 'html.parser')
with open("src/html/gentdelatorre.html", "r") as f:
    gent = BeautifulSoup(f, 'html.parser')

cards = ["Festa Major del Poble", "On fem la paella popular?", "Necessite transport a Alcoi"]

for c in cards:
    h1 = get_card_hash(events, c)
    h2 = get_card_hash(disseny, c)
    h3 = get_card_hash(gent, c)
    print(f"{c}:")
    print(f"  events.html: {h1}")
    print(f"  disseny.html: {h2}")
    print(f"  gentdelatorre.html: {h3}")
